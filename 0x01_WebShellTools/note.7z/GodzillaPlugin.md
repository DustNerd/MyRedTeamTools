```
//有效载荷的名字以及插件名  (插件名唯一不可重复)
@PluginAnnotation(
	payloadName = "CShapDynamicPayload",
	Name="FirstGodzillaPlugin", 
	DisplayName="FirstGodzillaPlugin"
) 

@PluginAnnotation(
    payloadName = "PhpDynamicPayload",
    Name = "ByPassOpenBasedir",
    DisplayName = "ByPassOpenBasedir"
)

@PluginAnnotation(
    payloadName = "JavaDynamicPayload",
    Name = "EnumDatabaseConn",
    DisplayName = "枚举数据库信息"
)
```

