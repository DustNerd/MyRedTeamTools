- phpadmin version
  - https://dev1.draytek.co.uk/pma/doc/html/index.html

- moodle version
  - http://seminari.abs.gov.rs/moodle/lib/upgrade.txt
  - http://obuka.mei.gov.rs/README.txt
  - https://github.com/inc0d3/moodlescan.git
  - app="moodle"

- Drupal 

  - https://defencepolicy.mod.bg/CHANGELOG.txt

  - https://spi.fpn.bg.ac.rs/core/install.php
  
    ```
    # In Drupal 7
    Open CHANGELOG.txt and the top most version will be the installed version.
    
    # In Drupal 8
    Open core/lib/Drupal.php file and there will be a version mentioned like const VERSION = '8.1.8';
    
    # Drush Tool
    Drush status
    
    # Admin Interface
    Go to Administer -> Reports -> Status Report or enter URL /admin/reports/status
    Above is the simplest way otherwise installed wappalyzer browser addons and see the magic.
    ```


  - https://stackoverflow.com/questions/2887282/how-to-find-version-of-drupal-installed

- Joomla 

  - https://www.itoctopus.com/how-to-quickly-know-the-version-of-any-joomla-website

  ```
  For Joomla websites >= 1.6.0
  
  Joomla websites, ever since version 1.6.0, have a very easy method that reveals their exact version (which may or may not be a good thing), all you need to do is to access the following URL:
  
  http://www.[thejoomlawebsite].com/administrator/manifests/files/joomla.xml
  
  The above URL will display an XML file containing the site’s version in the version XML element.
  
  Yes – it’s scarily easy, huh! It also applies to all versions of Joomla from 1.6.0 until 3.6.3 (including, of course, all the versions in the 2.5.x line), which is excellent!
  
  For Joomla websites >= 1.5.0 and <= 1.5.26
  
  Joomla websites in the 1.5.x line do not have the joomla.xml file, but there is another link that one can check, which is this one:
  
  http://www.[thejoomlawebsite].com/language/en-GB/en-GB.xml
  
  You can clearly see, in the XML version element, the version of the Joomla website in question. However, the problem here is that this method only reveals the major version, and not the minor version. The minor version is typically guessed by checking some core JavaScript files under the media/system/js folder.
  
  For Joomla websites < 1.5.0
  
  Before you say anything, yes, there are still some Joomla websites on the Internet using the 1.0.x versions (in fact, we worked on one back on Sunday). In order to know if a Joomla website is version 1.0.x, then all one needs to do is to check for the existence of a custom.xml file by visiting the following URL:
  
  http://[thejoomlawebsite].com/modules/custom.xml
  
  Similarly to the Joomla 1.5.x line, the Joomla 1.0.x line does not have a straightforward method to accurately determine the minor version of the Joomla website (for example, if it’s using version 1.0.0 or version 1.0.15). However, JavaScript files in the includes/js folder typically reveal information (such as file revisions) that will help determine the minor version of the Joomla website.
  
  In short…
  
      If the link http://[thejoomlawebsite].com/modules/custom.xml works: This is a Joomla 1.0.x website.
  
      If the link http://www.[thejoomlawebsite].com/administrator/manifests/files/joomla.xml works: This is a Joomla website with version >= 1.6.0, and the exact version number is stored in the version XML element of the file.
  
      If none of the above links works, then the Joomla website is a 1.5.x website.
  
  Again, the above assumes that you don’t have filesystem access to the website. If you do have access to the filesystem, then you can check the file version.php which tells you the exact version of the Joomla website. Unfortunately, the version.php file is not present in a standard location. Luckily, however, you have itoctopus on your side to let you know of its exact location for each Joomla version:
  
      For Joomla 1.0.x websites: The file version.php is located under the includes folder.
  
      For Joomla 1.5.x and Joomla 1.6.x: The file version.php is located under the libraries/joomla folder.
  
      For the short lived Joomla 1.7.x: The file version.php is (oddly) located under the includes folder (which is similar to 1.0.x websites).
  
      For Joomla 2.5.x and Joomla 3.x: The file version.php is located under the libraries/cms/version folder.
  
  We hope that you found this post useful. If you didn’t, or if you have just discovered (after following the above guide) that you are running a very old version of Joomla and you have decided that you want to update it, then please contact us. We are always here for you, we do the job right, and our fees are super duper affordable!
  ```

- ckeditor
  - https://archive.armf.bg/ckeditor/ckeditor.js 
  - top



- tiny_mce
  - http://sektorskepolitikeeu.mei.gov.rs/_cms/js/tiny_mce/tiny_mce_src.js
    - tinymce.majorVersion + '.' + tinymce.minorVersion
  - https://stackoverflow.com/questions/1284442/how-do-i-find-out-what-version-of-tinymce-i-am-running





- CodeIgniter

https://zeno.computing.dundee.ac.uk/2017-projects/krasi/user_guide/changelog.html
