## GO 

 



# os

## os/user

### 获取当前机器用户信息

- 在 Golang 语言中使用 os/user 包可以获取当前机器的用户信息。

- User 结构体

```
type User struct {
    Uid      string  // 用户的 ID
    Gid      string  // 用户所属组的 ID，如果属于多个组，那么此 ID 为主组的 ID
    Username string  // 用户名
    Name     string  // 属组名称，如果属于多个组，那么此名称为主组的名称
    HomeDir  string  // 用户的宿主目录
}
```

- 常用方法

```go
# 当前用户
func Current() (*User, error)

# 通过 Uid 获取用户
func LookupId(uid string) (*User, error)

# 通过 Username 获取用户
func Lookup(username string) (*User, error)
```

- 使用实例

```go
package main

import (
     "fmt"
     "os/user"
)

func handleErr(err error){
    if err != nil {
        fmt.Println(err)
    }
}

func main() {
    u, err := user.Current()
    handleErr(err)
    fmt.Println("Current User:")
    fmt.Printf("Gid %s\n", u.Gid)
    fmt.Printf("Uid %s\n", u.Uid)
    fmt.Printf("Username %s\n", u.Username)
    fmt.Printf("Name %s\n", u.Name)
    fmt.Printf("HomeDir %s\n", u.HomeDir)
    fmt.Println("")

    // 当前用户
    // Gid 20
    // Uid 501
    // Username wxnacy
    // Name wxnacy
    // HomeDir /Users/wxnacygo
}
```

## os/exec

### 运行外部命令

#### 查找可执行程序

- exec.LookPath 函数在 PATH 指定目录中搜索可执行程序，如 file 中有 /，则只在当前目录搜索。该函数返回完整路径或相对于当前路径的一个相对路径。

```go
func LookPath(file string) (string, error)
```

- 如果在 PATH 中没有找到可执行文件，则返回 exec.ErrNotFound。

#### Cmd及相关方法

- Cmd 结构代表一个正在准备或者在执行中的外部命令，调用了 Run、Output 或 CombinedOutput 后，Cmd 实例不能被重用。

```go
type Cmd struct {
    // Path 是将要执行的命令路径。
    // 该字段不能为空（也是唯一一个不能为空的字段），如为相对路径会相对于 Dir 字段。
    // 通过 Command 初始化时，会在需要时调用 LookPath 获得完整的路径。
    Path string

    // Args 存放着命令的参数，第一个值是要执行的命令（Args[0])；如果为空切片或者nil，使用 {Path} 运行。
    // 一般情况下，Path 和 Args 都应被 Command 函数设定。
    Args []string

    // Env 指定进程的环境变量，如为 nil，则使用当前进程的环境变量，即 os.Environ()，一般就是当前系统的环境变量。
    Env []string

    // Dir 指定命令的工作目录。如为空字符串，会在调用者的进程当前工作目录下执行。
    Dir string

    // Stdin 指定进程的标准输入，如为 nil，进程会从空设备读取（os.DevNull）
    // 如果 Stdin 是 *os.File 的实例，进程的标准输入会直接指向这个文件
    // 否则，会在一个单独的 goroutine 中从 Stdin 中读数据，然后将数据通过管道传递到该命令中（也就是从 Stdin 读到数据后，写入管道，该命令可以从管道读到这个数据）。在 goroutine 停止数据拷贝之前（停止的原因如遇到EOF或其他错误，或管道的 write 端错误），Wait 方法会一直堵塞。
    Stdin io.Reader

    // Stdout 和 Stderr 指定进程的标准输出和标准错误输出。
    // 如果任一个为 nil，Run 方法会将对应的文件描述符关联到空设备（os.DevNull）
    // 如果两个字段相同，同一时间最多有一个线程可以写入。
    Stdout io.Writer
    Stderr io.Writer

    // ExtraFiles 指定额外被新进程继承的已打开文件，不包括标准输入、标准输出、标准错误输出。
    // 如果本字段非 nil，其中的元素 i 会变成文件描述符 3+i。
    //
    // BUG: 在OS X 10.6系统中，子进程可能会继承不期望的文件描述符。
    // http://golang.org/issue/2603
    ExtraFiles []*os.File

    // SysProcAttr 提供可选的、各操作系统特定的 sys 属性。
    // Run 方法会将它作为 os.ProcAttr 的 Sys 字段传递给os.StartProcess 函数。
    SysProcAttr *syscall.SysProcAttr

    // Process 是底层的，只执行一次的进程。
    Process *os.Process

    // ProcessState 包含一个已经存在的进程的信息，只有在调用 Wait 或 Run 后才可用。
    ProcessState *os.ProcessState
}
```

- Command

  > 一般的，应该通过 exec.Command 函数产生 Cmd 实例：
  >
  > func Command(name string, arg ...string) *Cmd
  >
  > 该函数返回一个 *Cmd，用于使用给出的参数执行 name 指定的程序。返回的 *Cmd 只设定了 Path 和 Args 两个字段。
  >
  > 如果 name 不含路径分隔符，将使用 LookPath 获取完整路径；否则直接使用 name。参数 arg 不应包含命令名。
  >
  > 得到 *Cmd 实例后，接下来一般有两种写法：
  >
  > **调用 Start()，接着调用 Wait()，然后会阻塞直到命令执行完成；**
  > **调用 Run()，它内部会先调用 Start()，接着调用 Wait()；**

- Start
  - func (c *Cmd) Start() error
  - 开始执行 c 包含的命令，但并不会等待该命令完成即返回。Wait 方法会返回命令的退出状态码并在命令执行完后释放相关的资源。内部调用 os.StartProcess，执行 forkExec。

- Wait
  - func (c *Cmd) Wait() error
  - Wait 会阻塞直到该命令执行完成，该命令必须是先通过 Start 执行。
  - 如果命令成功执行，stdin、stdout、stderr 数据传递没有问题，并且返回状态码为 0，方法的返回值为 nil；如果命令没有执行或者执行失败，会返回 *ExitError 类型的错误；否则返回的 error 可能是表示 I/O 问题。
  - 如果 c.Stdin 不是 *os.File 类型，Wait 会等待，直到数据从 c.Stdin 拷贝到进程的标准输入。Wait 方法会在命令返回后释放相关的资源。

- Output
  - 除了 Run() 是 Start+Wait 的简便写法，Output() 更是 Run() 的简便写法，外加获取外部命令的输出。
  - func (c *Cmd) Output() ([]byte, error)
  - 它要求 c.Stdout 必须是 nil，内部会将 bytes.Buffer 赋值给 c.Stdout，在 Run() 成功返回后，会将 Buffer 的结果返回（stdout.Bytes())。

- CombinedOutput
  - Output() 只返回 Stdout 的结果，而 CombinedOutput 组合 Stdout 和 Stderr 的输出，即 Stdout 和 Stderr 都赋值为同一个 bytes.Buffer。

- StdoutPipe、StderrPipe 和 StdinPipe

> 除了上面介绍的 Output 和 CombinedOutput 直接获取命令输出结果外，还可以通过 StdoutPipe 返回 io.ReadCloser 来获取输出；相应的 StderrPipe 得到错误信息；而 StdinPipe 则可以往命令写入数据。
>
> func (c *Cmd) StdoutPipe() (io.ReadCloser, error)
>
> StdoutPipe 方法返回一个在命令 Start 执行后与命令标准输出关联的管道。Wait 方法会在命令结束后会关闭这个管道，所以一般不需要手动关闭该管道。但是在从管道读取完全部数据之前调用 Wait 出错了，则必须手动关闭。

> func (c *Cmd) StderrPipe() (io.ReadCloser, error)
>
> StderrPipe 方法返回一个在命令 Start 执行后与命令标准错误输出关联的管道。Wait 方法会在命令结束后会关闭这个管道，一般不需要手动关闭该管道。但是在从管道读取完全部数据之前调用 Wait 出错了，则必须手动关闭。

> func (c *Cmd) StdinPipe() (io.WriteCloser, error)
>
> StdinPipe 方法返回一个在命令 Start 执行后与命令标准输入关联的管道。Wait 方法会在命令结束后会关闭这个管道。必要时调用者可以调用 Close 方法来强行关闭管道。例如，标准输入已经关闭了，命令执行才完成，这时调用者需要显示关闭管道。
>
> 因为 Wait 之后，会将管道关闭，所以，要使用这些方法，只能使用 Start+Wait 组合，不能使用 Run。

#### 运行命令实例

- 前面讲到，通过 Cmd 实例后，有两种方式运行命令。有时候，我们不只是简单的运行命令，还希望能控制命令的输入和输出。通过上面的 API 介绍，控制输入输出有几种方法：

    得到 Cmd 实例后，直接给它的字段 Stdin、Stdout 和 Stderr 赋值；
    通过 Output 或 CombinedOutput 获得输出；
    通过带 Pipe 后缀的方法获得管道，用于输入或输出；

##### 直接赋值 Stdin、Stdout 和 Stderr

```go
func CmdRun1(cmdstr string) ([]string, error) {
	list := strings.Split(cmdstr, " ")
	cmd := exec.Command(list[0], list[1:]...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	outStr, errStr := string(stdout.Bytes()), string(stderr.Bytes())
	// fmt.Printf("out:\n%s\nerr:\n%s\n", outStr, errStr)
	results := []string{cmdstr, outStr, errStr}
	if err != nil {
		// log.Fatalf("cmd.Run() failed with %s\n", err)
		// fmt.Println("cmd.Run() failed with %s\n", err)
	}
	return results, err
}

func main() {
	res, err := CmdRun1("whoami1")
	fmt.Println(res[0])
	fmt.Println(res[1])
	fmt.Println(res[2])
	fmt.Println(err)
}

// Out:
whoami
win-xafdggfhsh\template


<nil>
```

##### 使用 Output

```go
func UseOutput(name string, arg ...string) ([]byte, error) {
    return exec.Command(name, arg...).Output()
}
```

##### 使用 Pipe

```go
func UsePipe(name string, arg ...string) ([]byte, error) {
    cmd := exec.Command(name, arg...)
    stdout, err := cmd.StdoutPipe()
    if err != nil {
        return nil, err
    }

    if err = cmd.Start(); err != nil {
        return nil, err
    }

    var out = make([]byte, 0, 1024)
    for {
        tmp := make([]byte, 128)
        n, err := stdout.Read(tmp)
        out = append(out, tmp[:n]...)
        if err != nil {
            break
        }
    }

    if err = cmd.Wait(); err != nil {
        return nil, err
    }

    return out, nil
}
```

### 进程相关操作

#### 启动进程

```go
func StartProcess(name string, argv []string, attr *ProcAttr) (*Process, error)
```

```go
func main() {
	if len(os.Args) < 2 {
		fmt.Printf("Usage: %s [command]\n", os.Args[0])
		os.Exit(1)
	}

	cmdName := os.Args[1]
	if filepath.Base(os.Args[1]) == os.Args[1] {
		if lp, err := exec.LookPath(os.Args[1]); err != nil {
			fmt.Println("look path error:", err)
			os.Exit(1)
		} else {
			cmdName = lp
		}
	}

	procAttr := &os.ProcAttr{
		Files: []*os.File{os.Stdin, os.Stdout, os.Stderr},
	}

	cwd, err := os.Getwd()
	if err != nil {
		fmt.Println("look path error:", err)
		os.Exit(1)
	}

	start := time.Now()
	process, err := os.StartProcess(cmdName, []string{cwd}, procAttr)
	if err != nil {
		fmt.Println("start process error:", err)
		os.Exit(2)
	}

	processState, err := process.Wait()
	if err != nil {
		fmt.Println("wait error:", err)
		os.Exit(3)
	}

	fmt.Println("pid", process.Pid)
	fmt.Println("real", time.Now().Sub(start))go
	fmt.Println("user", processState.UserTime())
	fmt.Println("system", processState.SystemTime())
}
```

#### 杀死进程

```go
func main() {
	pid := os.Getpid()
	process, error := os.FindProcess(pid)
	if error != nil {
		fmt.Println(error)
	}
	process.Kill()
	// 进行杀死 下面就不会执行了
	fmt.Println(pid)
	fmt.Println(process)
}
```

#### 进程终止

- os.Exit() 函数会终止当前进程，对应的系统调用不是 _exit，而是 exit_group。

```go
func Exit(code int)
```

- Exit 让当前进程以给出的状态码 code 退出。一般来说，状态码 0 表示成功，非 0 表示出错。进程会立刻终止，defer 的函数不会被执行。

## 环境变量相关

### 查看单个环境变量

```go
func Getenv(key string) string
```

```go
func main() {
  fmt.Println(os.Getenv("GOPATH"))
  fmt.Println(os.Getenv("GOROOT"))
}
```

### 查看所有环境变量

```go
func Environ() []string
```

```go
func main() {
 envs :=  os.Environ()
 for _,env := range envs{
   fmt.Println(env)
 }
}
```

### 查找指定环境变量

```go
func func Expand(s string, mapping func(string) string) string
func ExpandEnv(s string) string
```

```go
func main() {
  fmt.Println(os.Expand("${GOPATH}",os.Getenv))
  fmt.Println(os.ExpandEnv("${HOME}"))
}
```

### 查看指定值对应的环境变量

- key值是区分大小写的

```go
func LookupEnv(key string) (string, bool)
```

```go
func main() {
 name,_ :=  os.LookupEnv("HOME")
 fmt.Println(name)
}
```

### 设置环和取消环境变量go

```go
func Unsetenv(key string) error
func Setenv(key, value string) error
```

```go
func main() {
	os.Setenv("TMPDIR", "/my/tmp")
	defer os.Unsetenv("TMPDIR")
}
```

### 清除环境变量

```go
func Environ() []string
```

- go请谨慎操作



# gopsutil 

- 安装

```
go get github.com/shirou/gopsutil
```

- gopsutil将不同的功能划分到不同的子包中：

    cpu：CPU 相关；
    disk：磁盘相关；
    docker：docker 相关；
    host：主机相关；
    mem：内存相关；
    net：网络相关；
    process：进程相关；
    winservices：Windows 服务相关。

## gopsutil/host

- 子包 host可以获取主机相关信息，如开机时间、内核版本号、平台信息等等。

- host.BootTime() 返回主机开机时间的时间戳：
- 上面先获取开机时间，然后通过time.Unix()将其转为time.Time类型，最后输出2006-01-02 15:04:05格式的时间：

### 获取主机名，开机时间，系统/内核版本和平台信息

```go
func GetHostInfo() {
	info, _ := host.Info()
	fmt.Println("hostname: ", info.Hostname)
	uptime := time.Unix(int64(info.Uptime), 0)
	fmt.Println("uptime: ", uptime.Format("2006-01-02 15:04:05"))
	boottime := time.Unix(int64(info.BootTime), 0)
	fmt.Println("bootTime: ", boottime.Format("2006-01-02 15:04:05"))
	fmt.Println("os: ", info.OS)
	fmt.Println("platform: ", info.Platform)
	fmt.Println("platformFamily: ", info.PlatformFamily)
	fmt.Println("platformVersion: ", info.PlatformVersion)
	fmt.Println("kernelArch: ", info.KernelArch)
	fmt.Println("virtualizationSystem", info.VirtualizationSystem)
	fmt.Println("virtualizationRole: ", info.VirtualizationRole)
	fmt.Println("hostid: ", info.HostID)
}

func main() {
	GetHostInfo()
}
```

## gopsutil/process

- 子包 process可用于获取系统当前运行的进程信息，创建新进程，对进程进行一些操作等。

### 获取当前系统中运行的所有进程

- 方法一：

```go
func main() {
  pids, _ := process.Pids()
  for _, pid := range pids {
      pn, _ := process.NewProcess(pid)
      pName, _ := pn.Name()
      fmt.Println("ProcessName:", pName, "PID: ", pid)
  }
}
```

- 方法二：

```go
func main() {
 processes, _ := process.Processes()
 for _, p := range processes {
     pName, _ := p.Name()
     fmt.Println("ProcessName:", pName, "PID: ", p.Pid)
 }
}
```

### 杀死指定进程

```go
func main() {
	processes, _ := process.Processes()
	for _, p := range processes {
		pName, _ := p.Name()
		fmt.Println("ProcessName:", pName, "PID: ", p.Pid)
		//if p.Pid == 8936 {
		//	p.Kill()
		//}
		if pName == "notepad.exe" {     
			p.Kill()
		}
	}

}
```

### 判断进程是否存在

```go
func main() {
	//获取到所有进程的详细信息
	p1, _ := process.Pids() //获取当前所有进程的pid
	fmt.Println("p1:", p1)
	ifExists, _ := process.PidExists(10086) // 判断进程是否存在go
	fmt.Println("ifExists:", ifExists)
}

// Out：
p1: [1 125 126 129 130 131 132 135 138 139 141 146 151 155 156 157 164 165 166 167 168 170 171 172 174 177 178 180 181 186 187 188 191 192 194 195 197 198 200 201 202 203 204 206 207 209 215 222 230 239 247 248 254 257 258 259 260 286 384 385 391 414 444 446 447 449 451 471 483 493 495 502 516 519 525 528 533 534 535 536 538 541 542 546 548 549 552 555 558 559 560 561 562 563 565 566 568 571 572 574 576 577 578 580 581 582 583 586 590 595 597 600 601 621 622 624 625 628 629 632 633 639 641 642 643 644 652 654 658 659 660 661 662 665 667 670 671 682 685 686 688 689 691 696 697 698 713 718 719 720 737 793 802 1277 1278 1279 1282 1283 1286 1287 1313 1315 1379 1381 ...]
ifExists: false
```

# 文件目录相关

- go的文件目录相关操作散布在os、bufio、io包中

## 文件操作

### 新建文件

#### Create()  存在清空

> Create() 采用模式0666（任何人都可读写，不可执行）创建一个名为name的文件，如果文件已存在会截断它（即清空文件）。如果成功，返回的文件对象可用于I/O；对应的文件描述符具有O_RDWR模式。如果出错，错误底层类型是*PathError。

```go
func Create(name string) (*File, error)
```

```go
func CreateFile(filePath string) error {
	_, err := os.Create(filePath)
	if err != nil {
		log.Fatal("Create File Error", filePath)
		return err
	}
	return nil
}

func main() {
	CreateFile("./file.txt")
	CreateFile("C:\\Users\\template\\GolandProjects\\awesomeProject\\file1.txt")
}
```

#### OpenFile() 更多模式

> OpenFile() 是一个更一般性的文件打开函数，它会使用指定的选项（如O_RDONLY等）、指定的模式（如0666等）打开指定名称的文件。如果操作成功，返回的文件对象可用于I/O。如果出错，错误底层类型是*PathError。 

```go
func OpenFile(name string, flag int, perm FileMode) (file *File, err error)
```

- name：要打开的文件名 
- flag：打开文件的模式。 模式有以下几种：

|    模式     |   含义   |
| :---------: | :------: |
| os.O_WRONLY |   只写   |
| os.O_CREATE | 创建文件 |
| os.O_RDONLY |   只读   |
|  os.O_RDWR  |   读写   |
| os.O_TRUNC  |   清空   |
| os.O_APPEND |   追加   |

- perm：文件权限，一个八进制数。r（读）04，w（写）02，x（执行）01。

```
一般都文件属性标识如下： -rwxrwxrwx
第1位：文件属性，一般常用的是"-"，表示是普通文件；"d"表示是一个目录。
第2～4位：文件所有者的权限rwx (可读/可写/可执行)。
第5～7位：文件所属用户组的权限rwx (可读/可写/可执行)。
第8～10位：其他人的权限rwx (可读/可写/可执行)。

在golang中，可以使用os.FileMode(perm).String()来查看权限标识：
os.FileMode(0777).String()    //返回 -rwxrwxrwx
os.FileMode(0666).String()   //返回 -rw-rw-rw-
os.FileMode(0644).String()   //返回 -rw-r--r--
```

- 新建一个文件，若已存在会清空原文件

```go
func OpenCreate(filePath string,perm os.FileMode) error {
	_,err := os.OpenFile(filePath,os.O_CREATE,perm)
	if err != nil{
		log.Fatal("Open or Create Error：",filePath)
		return err
	}
	return nil
}

func main() {
	OpenCreate("./file2.txt", 0666)
	OpenCreate("C:\\Users\\template\\GolandProjects\\awesomeProject\\file3.txt", 0666)
}
```

- 新建一个文件，若已存在会在原文件基础上追加内容

```go
func OpenCreate(filePath string, perm os.FileMode) error {
	_, err := os.OpenFile(filePath, os.O_CREATE|os.O_RDWR|os.O_APPEND, perm)
	if err != nil {
		log.Fatal("Open or Create Error：", filePath)
		return err
	}
	return nil
}
func main() {
	OpenCreate("./file1.txt", 0666)
}
```

### 读取文件

#### Read() 读取最多n字节

> Read方法从f中读取最多len(b)字节数据并写入b。它返回读取的字节数和可能遇到的任何错误。文件终止标志是读取0个字节且返回值err为io.EOF。

```go
func (f *File) Read(b []byte) (n int, err error)
```

```go
func ReadnBytes(filePath string, n int) ([]byte, error) {
	file, err := os.Open(filePath)
	if err != nil {
		log.Fatal(err)
		return nil, err
	}
	defer file.Close()

	byteSlice := make([]byte, n)
	_, err = file.Read(byteSlice)
	if err != nil {
		log.Fatal(err)
		return nil, err
	}
	return byteSlice, nil
}

func main() {
	data, _ := ReadnBytes("./file.txt", 5)
	fmt.Printf(" data:%c,len:%v\n", data, len(data))
}

// Out：
 data:[f d s d s],len:5
```

#### ReadAtLeast() 读取最少n字节

> io里面的ReadAtLeast从r至少读取min字节数据填充进buf。函数返回写入的字节数和错误（如果没有读取足够的字节）。只有没有读取到字节时才可能返回EOF；如果读取了但不够时遇到了EOF，函数会返回ErrUnexpectedEOF。 如果min比buf的长度还大，函数会返回ErrShortBuffer。只有返回值err为nil时，返回值n才会不小于min。**这个函数的使用场景就在于被读文件不够时会报错unexpected EOF**
>

```go
func ReadAtLeast(r Reader, buf []byte, min int) (n int, err error)
```

```go
func ReadAtLeast(filePath string, n int) ([]byte, error) {
	file, err := os.Open(filePath)
	if err != nil {
		log.Fatal(err)
		return nil, err
	}
	byteSlice := make([]byte, 512)
	_, err = io.ReadAtLeast(file, byteSlice, n)
	if err != nil {
		log.Fatal(err)
		return nil, err
	}
	return byteSlice, nil
}

func main() {
	data, _ := ReadAtLeast("./file.txt", 5)
	fmt.Printf(" data:%c,len:%v\n", data, len(data))
}

// Out：
data:[f d s d s g s d g d s d g g g g g   ],len:512
```

#### ReadFull() 精确读取缓冲区长度的字节

> ReadFull从 r 精确地读取len(buf)字节数据填充进buf。函数返回写入的字节数和错误（如果没有读取足够的字节）。只有没有读取到字节时才可能返回EOF；如果读取了但不够时遇到了EOF，函数会返回ErrUnexpectedEOF。 只有返回值err为nil时，返回值n才会等于len(buf)。

```go
func ReadFull(r Reader, buf []byte) (n int, err error)
```

```go
func ReadExactly(filePath string, n int) ([]byte, error) {
	file, err := os.Open(filePath)
	if err != nil {
		log.Fatal(err)
		return nil, err
	}
	byteSlice := make([]byte, n)
	_, err = io.ReadFull(file, byteSlice)
	if err != nil {
		log.Fatal(err)
		return nil, err
	}
	return byteSlice, nil
}

func main() {
	data, _ := ReadExactly("./file.txt", 17)
	fmt.Printf(" data:%c,len:%v", data, len(data))
}
```

#### bufio.NewReader() 使用缓冲区

> NewReader创建一个具有默认大小缓冲、从r读取的 *Reader。

```go
func NewReader(rd io.Reader) *Reader
```

```go
func OpenWithBuffer(filepath string) ([]string, error) {
	file, err := os.Open(filepath)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	reader := bufio.NewReader(file)
	res := make([]string, 1)
	for {
		line, err := reader.ReadString('\n')
		res = append(res, line)
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
	}
	return res, nil
}

func main() {
	data, _ := OpenWithBuffer("./file.txt")
	fmt.Printf(" data:%v,len:%v", data, len(data))
}
```

#### scanner() 使用scanner

> NewScanner创建并返回一个从r读取数据的Scanner，默认的分割函数是ScanLines。 

```go
func NewScanner(r io.Reader) *Scanner
```

```go
func ReadWithScanner(filepath string) ([]string, error) {
	file, err := os.Open(filepath)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	scanner := bufio.NewScanner(file)
	res := make([]string, 1)
	for scanner.Scan() {
		res = append(res, scanner.Text())
	}
	return res, nil
}

func main() {
	data, _ := ReadWithScanner("./file.txt")
	fmt.Printf(" data:%s,len:%v", data, len(data))
}
```

#### * 逐行读取整个文件

> 使用 bufio.NewReader，和上面的使用缓冲区一样

```go
func ReadFileLine(filepath string) ([]string, error) {
	file, err := os.Open(filepath)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	reader := bufio.NewReader(file)
	res := make([]string, 1)
	for {
		line, err := reader.ReadString('\n')
		res = append(res, line)
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
	}
	return res, nil
}

func main() {
	data, _ := ReadFileLine("./file.txt")
	fmt.Printf(" data:%v,len:%v", data, len(data))
}
```

#### * 快速读取整个文件

> ioutil的ReadFile() 从filename指定的文件中读取数据并返回文件的内容。

```go
func ReadFile(filename string) ([]byte, error)
```

```go
func ReadFile(filepath string) ([]byte, error) {
	file, err := os.Open(filepath)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	fileCon, err := ioutil.ReadFile(filepath)
	if err != nil {
		return nil, err
	}
	return fileCon, nil
}

func main() {
	data, _ := ReadFile("./file.txt")
	fmt.Printf(" data:%c,len:%v", data, len(data))
}
```

### 写入文件

#### Write() 写入字节

> Write向文件中写入len(b)字节数据。它返回写入的字节数和可能遇到的任何错误。如果返回值n!=len(b)，本方法会返回一个非nil的错误。 

```go
func (f *File) Write(b []byte) (n int, err error)
```

```go
func WriteBytes(filePath string, content []byte) error {
	file, err := os.OpenFile(filePath, os.O_WRONLY, 0666)
	if err != nil {
		return err
	}
	defer file.Close()
	_, err = file.Write(content)
	if err != nil {
		return err
	}
	return nil
}

func main() {
	WriteBytes("./file.txt", []byte("dsgdsagsdgdsgdggggggggs"))
}
```

#### WriteString() 写入字符串

> WriteString类似Write，但接受一个字符串参数。

```go
func (f *File) WriteString(s string) (ret int, err error)
```

```go
func WriteStrings(filePath string, content string) error {
	file, err := os.OpenFile(filePath, os.O_WRONLY, 0666)
	if err != nil {
		return err
	}
	defer file.Close()
	_, err = file.WriteString(content)
	if err != nil {
		return err
	}
	return nil
}

func main() {
	WriteStrings("./file.txt", "dsgdsagsdgdsgdg13r53555")
}
```

- 注意：或许你以为是清空，或是追加，但都不是，它只是从头覆盖 

```go
# 清空后写
file,err := os.OpenFile(filePath,os.O_WRONLY|os.O_TRUNC,0666)
# 追加写
file,err := os.OpenFile(filePath,os.O_WRONLY|os.O_APPEND,0666)
```

#### WriteAt() 指定位置写入

> WriteAt在指定的位置（相对于文件开始位置）写入len(b)字节数据。它返回写入的字节数和可能遇到的任何错误。如果返回值n!=len(b)，本方法会返回一个非nil的错误。

```go
func (f *File) WriteAt(b []byte, off int64) (n int, err error)
```

```go
func WriteAt(filePath string, content []byte, at int64) error {
	file, err := os.OpenFile(filePath, os.O_WRONLY, 0666)
	if err != nil {
		return err
	}
	defer file.Close()
	_, err = file.WriteAt(content, at)
	if err != nil {
		return err
	}
	return nil
}

func main() {
	WriteAt("./file.txt", []byte("writeat"), 10)
	WriteAt("./file.txt", []byte("writeat"), 20)
}
```

#### bufio.NewWriter 使用缓冲区写入

```go
func WriteWithBuffer(filePath string) {
	file, err := os.OpenFile(filePath, os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer file.Close()
	writer := bufio.NewWriter(file)
	defer writer.Flush()
	for i := 0; i < 10; i++ {
		_, _ = writer.WriteString("lady_killer" + "\r\n")
	}
}

func main() {
	WriteWithBuffer("./file.txt")
}
```

#### WriteFile() 快速写入

> WriteFile将数据写入命名文件，必要时创建该文件。如果文件不存在，WriteFile使用perm权限创建它（在umask之前）；否则WriteFile会在写入之前将其截断，而不更改权限。

```go
func WriteFile(name string, data []byte, perm FileMode) error
```

- go源码

```go
# os.WriteFile
func WriteFile(name string, data []byte, perm FileMode) error {
	f, err := OpenFile(name, O_WRONLY|O_CREATE|O_TRUNC, perm)
	if err != nil {
		return err
	}
	_, err = f.Write(data)
	if err1 := f.Close(); err1 != nil && err == nil {
		err = err1
	}
	return err
}

# io/ioutil
func WriteFile(filename string, data []byte, perm fs.FileMode) error {
   return os.WriteFile(filename, data, perm)
}
```

- 使用实例

```go
func main() {
	os.WriteFile("./file.txt", []byte("111"), 0666)
}
```

## 目录操作

### 新建目录

#### 创建单个目录

> Mkdir() 使用指定的权限和名称创建一个目录。如果出错，会返回*PathError底层类型的错误。 

```go
func Mkdir(name string, perm FileMode) error
```

```go
func MkDir(dirPath string, perm os.FileMode) error {
	err := os.Mkdir(dirPath, perm)
	if err != nil {
		log.Fatal("Dir Exist or Create Dir Error：", dirPath)
		return err
	}
	return nil
}

func main() {
	MkDir("./file", 0666)
}
```

#### 递归创建多个目录

> MkdirAll使用指定的权限和名称创建一个目录，包括任何必要的上级目录，并返回nil，否则返回错误。权限位perm会应用在每一个被本函数创建的目录上。如果path指定了一个已经存在的目录，MkdirAll不做任何操作并返回nil。

```go
func MkdirAll(path string, perm FileMode) error
```

```go
func MkDirs(dirPath string, perm os.FileMode) error {
	err := os.MkdirAll(dirPath, perm)
	if err != nil {
		log.Fatal("Dir Exist or Create Dir Error：", dirPath)
		return err
	}
	return nil
}

func main() {
	MkDirs("./file1/test", 0666)
}
```

### 读取目录

#### 读取单层目录

> Readdir读取目录f的内容，返回一个有n个成员的[]FileInfo，这些FileInfo是被Lstat返回的，采用目录顺序。对本函数的下一次调用会返回上一次调用剩余未读取的内容的信息。
>
> 如果n>0，Readdir函数会返回一个最多n个成员的切片。这时，如果Readdir返回一个空切片，它会返回一个非nil的错误说明原因。如果到达了目录f的结尾，返回值err会是io.EOF。
>
> 如果n<=0，Readdir函数返回目录中剩余所有文件对象的FileInfo构成的切片。此时，如果Readdir调用成功（读取所有内容直到结尾），它会返回该切片和nil的错误值。如果在到达结尾前遇到错误，会返回之前成功读取的FileInfo构成的切片和该错误。

```go
func (f *File) Readdir(n int) (fi []FileInfo, err error)
```

```go
func readDir(dirname string, name, size, time bool) ([]fs.FileInfo, error) {
	f, err := os.Open(dirname)
	if err != nil {
		return nil, err
	}
	list, err := f.Readdir(-1)
	f.Close()
	if err != nil {
		return nil, err
	}
	if name == false && size == false && time == false {
		return nil, errors.New("you must choose a way for ordering")
	}
	if name {
		sort.Slice(list, func(i, j int) bool { return list[i].Name() < list[j].Name() })
	} else if size {
		sort.Slice(list, func(i, j int) bool { return list[i].Size() < list[j].Size() })
	} else if time {
		sort.Slice(list, func(i, j int) bool { return list[i].ModTime().Before(list[j].ModTime()) })
	}
	return list, nil
}

//通过名字排序
func ReadDirByName(dirname string) ([]fs.FileInfo, error) {
	return readDir(dirname, true, false, false)
}

//通过大小排序
func ReadDirBySize(dirname string) ([]fs.FileInfo, error) {
	return readDir(dirname, false, true, false)
}

//通过最后修改时间排序
func ReadDirByTime(dirname string) ([]fs.FileInfo, error) {
	return readDir(dirname, false, false, true)
}

func main() {
	dirpath := "./"
	lists, _ := ReadDirByName(dirpath)
	fmt.Println("------按照名字排序--------")
	fmt.Println("Current Dir: ", dirpath)
	for _, lst := range lists {
		fmt.Print(lst.Name(), " ", lst.ModTime(), "\n")
	}
	fmt.Println()
	fmt.Println("------按照大小排序--------")
	lists, _ = ReadDirBySize("./")
	for _, lst := range lists {
		fmt.Print(lst.Name(), " ")
	}
	fmt.Println()
	fmt.Println("------按照最后修改时间排序--------")
	lists, _ = ReadDirByTime("./")
	for _, lst := range lists {
		fmt.Print(lst.Name(), " ")
	}
	fmt.Println()
}
```

#### 递归读取所有目录

```go
//文件目录树形结构节点
type dirTreeNode struct {
	name  string
	size  int64
	time  time.Time
	child []dirTreeNode
}

//递归遍历文件目录
func getDirTree(pathName string) (dirTreeNode, error) {
	rd, err := ioutil.ReadDir(pathName)
	if err != nil {
		log.Fatalf("Read dir '%s' failed: %v", pathName, err)
	}
	var tree, childNode dirTreeNode
	tree.name = pathName
	var name, fullName string
	for _, fileDir := range rd {
		name = fileDir.Name()
		fsize := fileDir.Size()
		ftime := fileDir.ModTime()
		fullName = pathName + "/" + name
		if fileDir.IsDir() {
			childNode, err = getDirTree(fullName)
			if err != nil {
				log.Fatalf("Read dir '%s' failed: %v", fullName, err)
			}
		} else {
			childNode.name = name
			childNode.size = fsize
			childNode.time = ftime
			childNode.child = nil
		}
		tree.child = append(tree.child, childNode)
	}
	return tree, nil
}

//递归打印文件目录
func printDirTree(tree dirTreeNode, prefix string) {
	fmt.Println(prefix+" "+tree.name+" ", tree.size, "byte ", tree.time.Format("2006/01/02 15:04"))
	if len(tree.child) > 0 {
		prefix += "----"
		for _, childNode := range tree.child {
			printDirTree(childNode, prefix)
		}
	}
}

func main() {
	dirName := "."
	tree, err := getDirTree(dirName)
	if err != nil {
		log.Fatalln("read dir '%s' fail: %v", dirName, err)
	}
	printDirTree(tree, "")
}
```

### 切换目录

```go
func Chdir(dir string) error
```

```go
func main() {
	fmt.Println(os.Getwd())
	os.Chdir("./file2")
	fmt.Println(os.Getwd())
}

// Out：
PS C:\Users\template\GolandProjects\awesomeProject> go run .\test2.go
C:\Users\template\GolandProjects\awesomeProject <nil>
C:\Users\template\GolandProjects\awesomeProject\file2 <nil>
```

## 删除文件或目录

```go
func Remove(name string) error
```

- 删除文件

```go
func RemoveFile(filePath string) {
	error := os.Remove(filePath)
	if error != nil {
		fmt.Println(error)
	} else {
		fmt.Println("Remove file successful")
	}
}

func main() {
	RemoveFile("./file.txt")
}
```

- 删除空目录

```go
func RemoveDir(dirPath string) {
	error := os.Remove(dirPath)
	if error != nil {
		fmt.Println(error)
	} else {
		fmt.Println("Remove dir successful")
	}
}

func main() {
	RemoveDir("./file/")
}
```

- 删除任意非空目录

```
func RemoveAll(path string) error
```

```go
func RemoveDir(dirPath string) {
	error := os.RemoveAll(dirPath)
	if error != nil {
		fmt.Println(error)
	} else {
		fmt.Println("Remove dir successful")
	}
}

func main() {go
	RemoveDir("./file/")
}
```

> 在删除文件时，os.RemoveAll() 和 os.Remove() 方法没有太大的区别。但是在删除目录时，os.Remove() 只能删除空目录，而 os.RemoveAll() 不受任何限制，都可以删除。

## 移动文件或目录

```go
func Rename(oldpath, newpath string) error
```

```go
func MoveFileOrDir(oldpath, newpath string) {
	error := os.Rename(oldpath, newpath)
	if error != nil {
		fmt.Println(error)
	}
}

func main() {
	MoveFileOrDir("./file/test1.txt", "./file1/new_test1.txt")     // move file
	MoveFileOrDir("./file/", "./file1/file/")                      // move dir
}
```

## 复制文件或目录

```go
func Copy(dst Writer, src Reader) (written int64, err error)
```

```go
func CopyFile(src, dst string) error {
	var err error
	var srcfd *os.File
	var dstfd *os.File
	var srcinfo os.FileInfo

	if srcfd, err = os.Open(src); err != nil {
		return err
	}
	defer srcfd.Close()

	if dstfd, err = os.Create(dst); err != nil {
		return err
	}
	defer dstfd.Close()

	if _, err = io.Copy(dstfd, srcfd); err != nil {
		return err
	}
	if srcinfo, err = os.Stat(src); err != nil {
		return err
	}
	return os.Chmod(dst, srcinfo.Mode())
}

// Dir copies a whole directory recursively
func CopyDir(src string, dst string) error {
	var err error
	var fds []os.FileInfo
	var srcinfo os.FileInfo

	if srcinfo, err = os.Stat(src); err != nil {
		return err
	}

	if err = os.MkdirAll(dst, srcinfo.Mode()); err != nil {
		return err
	}

	if fds, err = ioutil.ReadDir(src); err != nil {
		return err
	}
	for _, fd := range fds {
		srcfp := path.Join(src, fd.Name())
		dstfp := path.Join(dst, fd.Name())

		if fd.IsDir() {
			if err = CopyDir(srcfp, dstfp); err != nil {
				fmt.Println(err)
			}
		} else {
			if err = CopyFile(srcfp, dstfp); err != nil {
				fmt.Println(err)
			}
		}
	}
	return nil
}

func main() {
	srcfile := "./file2/1.txt"
	destfile := "./test/2.txt"
	srcdir := "./file2"
	destdir := "./test3"
	CopyFile(srcfile, destfile)
	CopyDir(srcdir, destdir)
}
```

## 修改文件或目录名称

```go
func Rename(oldpath, newpath string) error
```

```go
func ModifyFileOrDir(oldname, newname string) {
	error := os.Rename(oldname, newname)
	if error != nil {
		fmt.Println(error)
	}
}

func main() {
	ModifyFileOrDir("./file1/new_test1.txt", "./file1/test.txt")
	ModifyFileOrDir("./file1/file", "./file1/new_file/")
}
```

## 获取文件信息

> Stat返回一个描述name指定的文件对象的FileInfo。如果指定的文件对象是一个符号链接，返回的FileInfo描述该符号链接指向的文件的信息，本函数会尝试跳转该链接。如果出错，返回的错误值为*PathError类型。

```go
 func Stat(name string) (fi FileInfo, err error)
```

```go
func DisplayFileInfo(filePath string) {
	fileInfo, err := os.Stat(filePath)
	if err != nil {
		log.Fatal(err)
	}
    fmt.Println("File name:", fileInfo.Name())
    fmt.Println("Size in bytes:", fileInfo.Size())
    fmt.Println("Permissions:", fileInfo.Mode())
    fmt.Println("Last modified:", fileInfo.ModTime())
    fmt.Println("Is Directory: ", fileInfo.IsDir())
    fmt.Printf("System interface type: %T\n", fileInfo.Sys())
    fmt.Printf("System info: %+v\n\n", fileInfo.Sys())
}

func main() {
	DisplayFileInfo("./file.txt")
}
```

## 判断文件或目录是否存在

> 利用前面提到的Stat和os的IsNotExist函数。

```go
func CheckFileIsExist(filename string) bool {
	var exist = true
	if _, err := os.Stat(filename); os.IsNotExist(err) {
		exist = false
	}
	return exist
}

func main() {
	ok := CheckFileIsExist("./file.txt")
	fmt.Println("./file.txt exist？",ok)
	ok = CheckFileIsExist("../file")
	fmt.Println("./file exist？",ok)
}
```

# 哈希和摘要

- 复制整个文件内容到内存中，传递给hash函数

```go
func GetHash(filePath string) {
	// 得到文件内容
	data, err := ioutil.ReadFile(filePath)
	if err != nil {
		log.Fatal(err)
	}
	// 计算Hash
	fmt.Printf("Md5: %x\n\n", md5.Sum(data))
	fmt.Printf("Sha1: %x\n\n", sha1.Sum(data))
	fmt.Printf("Sha256: %x\n\n", sha256.Sum256(data))
	fmt.Printf("Sha512: %x\n\n", sha512.Sum512(data))
}

func main() {
	GetHash("./file2/1.txt")
}
```

- 创建一个hash writer, 使用Write、WriteString、Copy将数据传给它

```go
func GetHash(filePath string) {
	// 得到文件内容
	file, err := os.Open(filePath)
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()
	//创建一个新的hasher,满足writer接口
	hasher := md5.New()
	_, err = io.Copy(hasher, file)
	if err != nil {
		log.Fatal(err)
	}
	// 计算hash并打印结果。
	// 传递 nil 作为参数，因为我们不通参数传递数据，而是通过writer接口。
	// 计算Hash
	data := hasher.Sum(nil)
	fmt.Printf("Md5: %x\n\n", md5.Sum(data))
	fmt.Printf("Sha1: %x\n\n", sha1.Sum(data))
	fmt.Printf("Sha256: %x\n\n", sha256.Sum256(data))
	fmt.Printf("Sha512: %x\n\n", sha512.Sum512(data))
}

func main() {
	GetHash("./file2/1.txt")
}
```

# 时间格式化

> 时间类型有一个自带的方法Format进行格式化，需要注意的是Go语言中格式化时间模板不是常见的Y-m-d H:M:S而是使用Go的诞生时间2006年1月2号15点04分（记忆口诀为2006 1 2 3 4）。也许这就是技术人员的浪漫吧。
> 补充：如果想格式化为12小时方式，需指定PM。

```go
func main() {
	now := time.Now()
	// 格式化的模板为Go的出生时间2006年1月2号15点04分 Mon Jan
	// 24小时制
	fmt.Println(now.Format("2006-01-02 15:04:05.000 Mon Jan"))
	// 12小时制
	fmt.Println(now.Format("2006-01-02 03:04:05.000 PM Mon Jan"))
	fmt.Println(now.Format("2006/01/02 15:04"))
	fmt.Println(now.Format("15:04 2006/01/02"))
	fmt.Println(now.Format("2006/01/02"))
}

Output:

$ go run main.go
2020-05-24 09:50:08.741 Sun May
2020-05-24 09:50:08.741 AM Sun May
2020/05/24 09:50
09:50 2020/05/24
2020/05/24
```

当然你也可以将字符串解析为你想要的时间格式：

```go
func main() {
	now := time.Now()
	fmt.Println(now)
	// 加载时区
	loc, err := time.LoadLocation("Asia/Shanghai")
	if err != nil {
		fmt.Println(err)
		return
	}
	// 按照指定时区和指定格式解析字符串时间
	timeObj, err := time.ParseInLocation("2006/01/02 15:04:05", "2019/08/04 14:15:20", loc)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(timeObj)
}

Output:
$ go run main.go
2020-05-24 09:52:52.7381466 +0800 CST m=+0.009007901
2019-08-04 14:15:20 +0800 CST
```

# 调用 Windows API

## 概述

- 我们可以利用syscall包和unsafe包与系统直接通信。可参考：
  - https://github.com/golang/go/wiki/WindowsDLLs

- 注意unsafe包操作内存是不安全的，在使用的时候要了解我们能做什么和不能做什么，具体可参考官方文档：
  - https://pkg.go.dev/unsafe
- Windows API文档可参考官方文档：
  - https://docs.microsoft.com/en-us/windows/win32/apiindex/api-index-portal
  - https://docs.microsoft.com/en-us/windows/win32/api/

## 要点

### 加载DLL

第一步就是加载要使用的API所在的DLL。有两种方法：

- 懒加载
  - 使用syscall.NewLazyDLL以懒加载方式加载DLL，返回 *LazyDLL，只在第一次调用其函数时才加载DLL

```go
var（
	kernel32DLL = syscall.NewLazyDLL("kernel32.dll")
）
```

- 立即加载
  - 使用syscall.LoadLibrary来立即加载DLL

```go
var（
    kernel32, _ = syscall.LoadLibrary("kernel32.dll")
）
```

### 获得函数

> 与加载DLL方式对应，采用不同方式获得函数：

- 懒加载时调用 **dll. NewProc("ProcedureName")**

```go
procOpenProcess = kernel32DLL.NewProc(“OpenProcess”)
```

- 立即加载时，调用 **syscall.GetProcAddress**

```go
findWindow, _ := syscall.GetProcAddress(user32, "FindWindowW")
```

### 调用函数

一旦有个这些引用，我们就可以Call这个函数本身的方法，或者使用syscall.Syscall函数及其变体进行API调用。使用的过程中发现Call方法更方便，但syscall.Syscall性能更优。根据函数参数的多数，我们可以使用。

与加载DLL方式对应，采用不同方式调用函数：

- 懒加载时调用 **proc.Call** 函数

- 立即加载时调用 **syscall.Syscall** 函数及其变体。

  - 目前Go v1.12中，无法调用超过15个参数的函数。虽然我没有遇到过，但在于OpenGL中确实有这种情况。
  - 您可以通过调用该函数 SyscallX（其中 X 是参数的数量。如果函数的参数数量少于此数量，例如将 7 个参数传递给接受 9 个参数的函数， Syscall9仍然可以工作，您只需要指定 7 作为您的第二个参数 Syscall9）。 
  - syscall包下面有5个关于系统调用的方法，分别表示调用参数的个数。

  ```go
  func Syscall(trap, nargs, a1, a2, a3 uintptr) (r1, r2 uintptr, err Errno)
  func Syscall6(trap, nargs, a1, a2, a3, a4, a5, a6 uintptr) (r1, r2 uintptr, err Errno)
  func Syscall9(trap, nargs, a1, a2, a3, a4, a5, a6, a7, a8, a9 uintptr) (r1, r2 uintptr, err Errno)
  func Syscall12(trap, nargs, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12 uintptr) (r1, r2 uintptr, err Errno)
  func Syscall15(trap, nargs, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15 uintptr) (r1, r2 uintptr, err Errno)
  ------------------------------------------------------------------------------------
  syscall.Syscall ：少于4个参数
  syscall.Syscall6：4到6个参数
  syscall.Syscall9：7到9个参数
  syscall.Syscall12：10到12个参数
  syscall.Syscall15：13到15个参数
  ```
  
  - **第二个参数, nargs 即参数的个数,一旦传错,  轻则调用失败 , 重者直接崩溃 多余的参数, 用0代替。**

### 数据类型

- Windows常见数据类型可以参考如下：

```go
type (
         BOOL          uint32
         BOOLEAN       byte
         BYTE          byte
         DWORD         uint32
         DWORD64       uint64
         HANDLE        uintptr
         HLOCAL        uintptr
         LARGE_INTEGER int64
         LONG          int32
         LPVOID        uintptr
         SIZE_T        uintptr
         UINT          uint32
         ULONG_PTR     uintptr
         ULONGLONG     uint64
         WORD          uint16
)
```

字符串类型：

- Windows中有2种类型：ANSI编码和UTF-16编码。一般使用UTF-16，可利用syscall.UTF16PtrFromString进行转换。

- Call和Syscall函数里面传入的Windows API函数的参数都是uintptr类型，对指针类型需要通过unsafe.Pointer函数来转换，比如：

```
uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(text)))
```

- 对数值类型可以直接转换，NULL可用0表示
- 比对：
  - https://docs.microsoft.com/en-us/windows/win32/winprog/windows-data-types
  - https://pkg.go.dev/golang.org/x/sys/windows?utm_source=godoc#SecurityAttributes
  - https://cs.opensource.google/go/x/sys/+/87db552b:windows/types_windows.go
  - https://cs.opensource.google/go/x/sys/+/87db552b:windows/syscall_windows.go
  - https://go.dev/src/syscall/syscall_windows.go


### 卸载DLL

- 不再需要使用DLL里的函数之后可以卸载DLL，可使用syscall.FreeLibrary来卸载。

```GO
defer syscall.FreeLibrary(kernel32)
```

## 示例

### 立即加载示例

- 以下示例以立即加载方式调用MessageBoxW API：

```go
package main

import (
	"fmt"
	"syscall"
	"unsafe"
)

func abort(funcname string, err error) {
	panic(fmt.Sprintf("%s failed: %v", funcname, err))
}

var (
	kernel32, _        = syscall.LoadLibrary("kernel32.dll")
	getModuleHandle, _ = syscall.GetProcAddress(kernel32, "GetModuleHandleW")

	user32, _     = syscall.LoadLibrary("user32.dll")
	messageBox, _ = syscall.GetProcAddress(user32, "MessageBoxW")
)

const (
	MB_OK                = 0x00000000
	MB_OKCANCEL          = 0x00000001
	MB_ABORTRETRYIGNORE  = 0x00000002
	MB_YESNOCANCEL       = 0x00000003
	MB_YESNO             = 0x00000004
	MB_RETRYCANCEL       = 0x00000005
	MB_CANCELTRYCONTINUE = 0x00000006
	MB_ICONHAND          = 0x00000010
	MB_ICONQUESTION      = 0x00000020
	MB_ICONEXCLAMATION   = 0x00000030
	MB_ICONASTERISK      = 0x00000040
	MB_USERICON          = 0x00000080
	MB_ICONWARNING       = MB_ICONEXCLAMATION
	MB_ICONERROR         = MB_ICONHAND
	MB_ICONINFORMATION   = MB_ICONASTERISK
	MB_ICONSTOP          = MB_ICONHAND

	MB_DEFBUTTON1 = 0x00000000
	MB_DEFBUTTON2 = 0x00000100
	MB_DEFBUTTON3 = 0x00000200
	MB_DEFBUTTON4 = 0x00000300
)

func MessageBox(caption, text string, style uintptr) (result int) {
	var nargs uintptr = 4
	ret, _, callErr := syscall.Syscall9(uintptr(messageBox),
		nargs,
		0,
		uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(text))),
		uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(caption))),
		style,
		0,
		0,
		0,
		0,
		0)
	if callErr != 0 {
		abort("Call MessageBox", callErr)
	}
	result = int(ret)
	return
}

func GetModuleHandle() (handle uintptr) {
	var nargs uintptr = 0
	if ret, _, callErr := syscall.Syscall(uintptr(getModuleHandle), nargs, 0, 0, 0); callErr != 0 {
		abort("Call GetModuleHandle", callErr)
	} else {
		handle = ret
	}
	return
}

func main() {
	defer syscall.FreeLibrary(kernel32)
	defer syscall.FreeLibrary(user32)

	fmt.Printf("Return: %d\n", MessageBox("Done Title", "This test is Done.", MB_YESNOCANCEL))
}

func init() {
	fmt.Print("Starting Up\n")
}
```

### 懒加载示例

- 以下示例则以懒加载方式调用MessageBoxW API，实现上面示例的同样功能：

```go
package main

import (
	"fmt"
	"syscall"
	"unsafe"
)

func main() {
	var mod = syscall.NewLazyDLL("user32.dll")
	var proc = mod.NewProc("MessageBoxW")
	var MB_YESNOCANCEL = 0x00000003

	ret, _, _ := proc.Call(0,
		uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr("This test is Done."))),
		uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr("Done Title"))),
		uintptr(MB_YESNOCANCEL))
	fmt.Printf("Return: %d\n", ret)

}
```

## 小结

- 在GO语言里面调用Windows API主要有三种方式：**立即加载方式和懒加载方式**，CGO
- 两种方式在获得函数和调用函数上稍有不同，但传参是类似的，需要小心处理。并且仅在 Windows 中可用。

- 通过“链接”库，使用“ cgo ”方法（这种方式适用于 Linux 和 Windows）。
  -  CGO Wiki：https://github.com/golang/go/wiki/cgo 
  - 例子：

```go
import ("C")
...
C.MessageBoxW(...)
```

- 参考：https://razeen.me/posts/breaking-all-the-rules-using-go-to-call-windows-api/

