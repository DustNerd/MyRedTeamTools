<a name="UTLQm"></a>
# 0x00 常用语法
<a name="n9OAh"></a>
## 00 主函数
```python
def main():
    print("Hello, World!")
if __name__== "__main__" :
    main()
```
<a name="laZPv"></a>
## 01 变量

- Python中变量类型有：数字(Numbers)、布尔类型、字符串(Stuing)、列表(List)、元组(Tuple)、字典(Dictionary)
- 查看变量类型
   - isinstance()函数 可以用来判断变量的类型，它返回的是一个布尔值，False or True.
   - type() 返回对象的类型
   - 区别之处：type()不会认为子类是一种父类类型，isinstance()会认为子类是一种父类类型
```python
# isinstance()
>>> isinstance("123",str)
>>> True
>>> isinstance(123,int)
>>> True
>>> isinstance({'123'},list)
>>> False
>>> isinstance(['123'],list)
>>> True

# type() 返回对象的类型
v = "test"
print(type(v))  # 输出 <class 'str'>
```
<a name="gfHpC"></a>
## 02 遍历

- **遍历列表**
```python
names = ['jack', 'kaer', 'rose']
for name in names:
    print(name)

for name in ['jack', 'kaer', 'rose']:
    print(name)
```

- 遍历元组
```python
names = ('jack', 'kaer', 'rose')
for name in names:
    print(name)

for name in ('jack', 'kaer', 'rose'):
    print(name)
```

- 遍历字典
```python
# 遍历字典的key
Student_grade = {
    "jack":100,
    "rose":80,
    "kaer":59,
    "tom":59
}
 
for key in Student_grade.keys():
    print (key)

# 遍历字典的value
Student_grade = {
    "jack":100,
    "rose":80,
    "kaer":59,
    "tom":59
}
 
for value in Student_grade.values():
    print (value)


# 遍历字典的每一个元素
Student_grade = {
    "jack":100,
    "rose":80,
    "kaer":59,
    "tom":59
}
 
for item in Student_grade.items(): # 注意：xx.items(): 返回可迭代对象，内部是元组，元组有2个数据，元组数据1是字典的key，元组数据2是字典的value
    print (item)
```
<a name="GMkeK"></a>
## 03 随机值

- [https://blog.csdn.net/weixin_45841831/article/details/127414276](https://blog.csdn.net/weixin_45841831/article/details/127414276)
<a name="IPRAL"></a>
## 04 UUID
```python
import uuid   # 引入python自带的uuid模块
 
if __name__ == '__main__':
    #这个是根据当前的时间戳和MAC地址生成的，最后的12个字符408d5c985711对应的就是MAC地址，因为是MAC地址，那么唯一性应该不用说了。但是生成后暴露了MAC地址这就很不好了。
    print(uuid.uuid1())
    
    #里面的namespace和具体的字符串都是我们指定的，然后呢···应该是通过MD5生成的，这个我们也很少用到，莫名其妙的感觉。
    print(uuid.uuid3(uuid.NAMESPACE_DNS, 'tongyao'))
    
    #这是基于随机数的uuid，既然是随机就有可能真的遇到相同的，但这就像中奖似的，几率超小，因为是随机而且使用还方便，所以使用这个的还是比较多的。
    print(uuid.uuid4())
    
    #这个看起来和uuid3()貌似并没有什么不同，写法一样，也是由用户来指定namespace和字符串，不过这里用的散列并不是MD5，而是SHA1。
    print(uuid.uuid5(uuid.NAMESPACE_DNS, 'tongyao'))
    
    
    #去掉uuid中间-
    uid = str(uuid.uuid4())
    uuid = ''.join(uid.split('-'))
    print(uuid)
    
    input()
```
<a name="NHwTB"></a>
# 0x01 网络请求
<a name="m7Uir"></a>
## 00 安装 Requests 库
```python
pip install requests
```
<a name="f1gJO"></a>
## 01 GET 请求
```python
import requests

# 基本GET请求
r = requests.get("http://www.baidu.com/")  # 其他写法：r = requests.request("get", "http://www.baidu.com/")
print(r)                                   # 返回结果为 Response对象

# 添加查询参数 和 headers
params = {'key1': 'value', 'key2': 'value2'}

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36",
    "Connect": "keep-alive"
}

# params 接收一个字典或者字符串的查询参数，字典类型自动转换为url编码，不需要urlencode()
r = requests.get("http://www.baidu.com/", params = params, headers = headers)
print(r.text)                             # 查看响应内容，response.text 返回的是Unicode格式的数据
print(r.content)                          # 查看响应内容，response.content返回的字节流数据
print(r.encoding)                         # 查看响应头部字符编码
print(r.url)                              # 查看完整url地址
print(r.status_code)                 	  # 查看响应码
print(r.cookies)                          # 查看 cookies 信息
print(r.headers)                          # 查看 响应头信息
print(r.headers['Content-Type'])          # 查看 响应头 Content-Type 信息
print(r.headers['Date'])                  # 查看 响应头 Date 信息
```
<a name="g8awy"></a>
## 02 POST 请求
```python
import requests

# 基本POST请求（data参数）
simpledata = 1
r = requests.post("http://www.baidu.com/", data=simpledata)
print(r)                  # 返回结果为 Response对象

# 添加headers 和 form表单数据
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0 Win64 x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36",
    "Connect": "keep-alive"
}

formdata = {
    "type": "AUTO",
    "i": "i love python",
    "doctype": "json",
    "xmlVersion": "1.8",
    "keyfrom": "fanyi.web",
    "ue": "UTF-8",
    "action": "FY_BY_ENTER",
    "typoResult": "true"
}

url = "http://fanyi.youdao.com/translate?smartresult=dict&smartresult=rule&smartresult=ugc&sessionFrom=null"
r = requests.post(url, data=formdata, headers=headers)
print(r.text)                         # 查看响应内容，response.text 返回的是Unicode格式的数据
print(r.content)                      # 查看响应内容，response.content返回的字节流数据
print(r.encoding)                     # 查看响应头部字符编码
print(r.url)                          # 查看完整url地址
print(r.status_code)                  # 查看响应码
print(r.cookies)                      # 查看 cookies 信息
print(r.headers)                      # 查看 响应头信息
print(r.headers['Content-Type'])      # 查看 响应头 Content-Type 信息
print(r.headers['Date'])              # 查看 响应头 Date 信息


# 如果是json文件可以直接显示
print(r.json()) 
```
<a name="tNIql"></a>
## 03 代理（proxies参数）

- 如果需要使用代理，你可以通过为任意请求方法提供 proxies 参数来配置单个请求：
```python
import requests
 
# 根据协议类型，选择不同的代理
proxies = {
  "http": "http://12.34.56.79:9527",
  "https": "http://12.34.56.79:9527",
}
 
response = requests.get("http://www.baidu.com", proxies = proxies)
print(r.text) 
```
<a name="e62yV"></a>
## 04 Cookies 和 Session

- Cookies
```python
import requests

response = requests.get("http://www.baidu.com/")
# 返回 CookieJar对象:
cookiejar = response.cookies

# 将CookieJar转为字典：
cookiedict = requests.utils.dict_from_cookiejar(cookiejar)
print(cookiejar)
print(cookiedict)
```

- Sission
   - 在 requests 里，session对象是一个非常常用的对象，这个对象代表一次用户会话：从客户端浏览器连接服务器开始，到客户端浏览器与服务器断开。
   - 会话能让我们在跨请求时候保持某些参数，比如在同一个 Session 实例发出的所有请求之间保持 cookie 。
   - 实现网登录
```python
import requests
 
# 1. 创建session对象，可以保存Cookie值
ssion = requests.session()
 
# 2. 处理 headers
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36"}
 
# 3. 需要登录的用户名和密码
data = {"email":"mr_mao_hacker@163.com", "password":"alarmchime"}  
 
# 4. 发送附带用户名和密码的请求，并获取登录后的Cookie值，保存在ssion里
ssion.post("http://www.renren.com/PLogin.do", data = data)
 
# 5. ssion包含用户登录后的Cookie值，可以直接访问那些登录后才可以访问的页面
response = ssion.get("http://www.renren.com/410043129/profile")
 
# 6. 打印响应内容
print(response.text)
```
<a name="ZTB0A"></a>
## 05 处理SSL证书验证

- 要想检查某个主机的SSL证书，你可以使用 verify 参数（也可以不写）
```python
import requests
response = requests.get("https://www.baidu.com/", verify=True)
 
# 也可以省略不写
# response = requests.get("https://www.baidu.com/")
print(response.text)
```

- 忽略 SSL证书 (某些情况下，SSL证书影响正常访问页面时使用)
```python
import requests
response = requests.get("https://www.baidu.com/", verify=False)
print(response.text)
```

- 禁用安全请求警告
```python
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
```
<a name="tyJuq"></a>
## 06 自定义超时时间
```python
import requests
response = requests.get("https://www.baidu.com/", timeout=10)   # 设置超时时间为10秒
print(response.text)
```
<a name="LiLdP"></a>
## 07 处理301/302自动跳转

- 设置属性:** allow_redirects = True** ，则head方式会自动解析重定向链接，requests.get()方法的allow_redirects默认为True，head方法默认为False
```python
import requests
response = requests.get("https://www.baidu.com/", allow_redirects = True)    # 设置允许301/302自动跳转
print(response.text)

response = requests.get("https://www.baidu.com/", allow_redirects = False)   # 设置禁止301/302自动跳转
print(response.text)
```
<a name="kpZA4"></a>
## 08 设置随机UA头
```python
import requests
import random

def main():
    user_agent_list = [
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1",
        "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6",
        "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5",
        "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.36 Safari/536.5",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.0 Safari/536.3",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",
        "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_2 like Mac OS X) App leWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D257 Safari/9537.53"
    ]

    UA = random.choice(user_agent_list)  # 获取随机的 User_Agent
    headers = {'User_Agent': UA}

    response = requests.get("https://www.baidu.com/", headers=headers) 
    print(response.status_code)
    print(UA)
if __name__== "__main__" :
    main()
```
<a name="uL0i1"></a>
# 0x02 文件读写
<a name="fHaw7"></a>
## 00 打开/关闭文件

- **open()** & **close()**
```python
open('file','mode')
```
```python
f = open(file) # 打开文件
f.close()      # 关闭文件
```
> 参数解释<br />**file：**需要打开的文件路径<br />**mode（可选）：**打开文件的模式，如只读、追加、写入等

> **mode常用的模式：**
> - r：表示文件只能读取
> - w：表示文件只能写入
> - a：表示打开文件，在原有内容的基础上追加内容，在末尾写入
> - w+:表示可以对文件进行读写双重操作
> 
mode参数可以省略不填，默认为r模式mode参数还可以指定以什么样的编码方式读写文本，默认情况下open是以文本形式打开文件的，比如上面的四种mode模式。
> **当你需要以字节（二进制）形式读写文件时**，只需要在mode参数中追加'b'即可：
> - rb：以二进制格式打开一个文件，用于只读
> - wb：以二进制格式打开一个文件，用于只写
> - ab：以二进制格式打开一个文件，用于追加
> - wb+: 以二进制格式打开一个文件，用于读写

- **with 关键字**
   - 在打开文件时，很多人通常直接用open('file')，这样并不酷。最好使用 with 关键字。优点是当子句体结束后文件会正确关闭，即使在某个时刻引发了异常。
```python
with open('1.txt') as f:
    content = f.read()
```
<a name="gRMwG"></a>
## 01 读文件

- python文件对象提供了三个“读”方法： read()、readline() 和 readlines()。每种方法可以接受一个变量以限制每次读取的数据量。
   - **read() **每次读取整个文件，它通常用于将文件内容放到一个字符串变量中。参数 size（可选）为数字，表示从已打开文件中读取的字节计数，默认情况下为读取全部。
   - **readline()** 每次只读取一行，包括换行符'\n'，通常比readlines() 慢得多。仅当没有足够内存可以一次读取整个文件时，才应该使用 readline()。换行符（\n）留在字符串的末尾，如果文件不以换行符结尾，则在文件的最后一行省略，这使得返回值明确无误。如果 f.readline() 返回一个空的字符串，则表示已经到达了文件末尾，而空行使用 '\n' 表示，该字符串只包含一个换行符。参数 size（可选）为数字，表示从已打开文件中读取的字节计数
   - **readlines() **和 readline() 长得像，但功能不一样，前面说过 readline() 只读取一行，readlines方法则是读取所有行，返回的是所有行组成的列表。
```python
# read()
with  open('1.txt') as f:
    content = f.read()      # 读取整个文件
    print(content)

with  open('1.txt') as f:
    content = f.read(10)    # 读取前10个字节
    print(content)

# readline()
with  open('1.txt') as f:
    print(f.readline())     # 读取第1行
    print(f.readline(5))    # 读取第2行前5个字节

# readlines() 
with  open('1.txt') as f:
    print(f.readlines())    # 读取所有行

with  open('1.txt') as f:
    print(f.readlines()[0]) # 读取所有行并输出第1行内容
    
iplist = []    
with open("iptest.txt") as f:
    for line in f:
        iplist.append(line.strip())   
```
<a name="FT5xf"></a>
## 02 写文件

- **write()**
   - 它只有一个参数：参数[str]代表要写入的字符串
```python
# 覆盖写
with open('1.txt', 'w') as f:
	f.write('hello,my friends!\nthis is python big data analysis\n')

# 追加写
with open('1.txt', 'a') as f:
	f.write('hello,my friends!\n')
```
<a name="XYJ2C"></a>
# 0x03 数据处理
<a name="nKvfu"></a>
## 00 Regex 正则表达式
<a name="pRxsv"></a>
### 001 re.match()
re.match 尝试从字符串的**起始位置匹配**一个模式，如果不是起始位置匹配成功的话，match() 就返回 none。<br />**函数语法**：

- re.match(pattern, string, flags=0)

函数参数说明：

| 参数 | 描述 |
| --- | --- |
| pattern | 匹配的正则表达式 |
| string | 要匹配的字符串。 |
| flags | 标志位，用于控制正则表达式的匹配方式，如：是否区分大小写，多行匹配等等。参见：[正则表达式修饰符 - 可选标志](https://www.runoob.com/python/python-reg-expressions.html#flags) |

匹配成功 re.match 方法返回一个匹配的对象，否则返回 None。我们可以使用 group(num) 或 groups() 匹配对象函数来获取匹配表达式。

| 匹配对象方法 | 描述 |
| --- | --- |
| group(num=0) | 匹配的整个表达式的字符串，group() 可以一次输入多个组号，在这种情况下它将返回一个包含那些组所对应值的元组。 |
| groups() | 返回一个包含所有小组字符串的元组，从 1 到 所含的小组号。 |

```python
import re
print(re.match('www', 'www.runoob.com').span())  # 在起始位置匹配
print(re.match('com', 'www.runoob.com'))         # 不在起始位置匹配

line = "Cats are smarter than dogs"
matchObj = re.match(r'(.*) are (.*?) .*', line, re.M | re.I)
if matchObj:
    print("matchObj.group() : ", matchObj.group())
    print("matchObj.group(1) : ", matchObj.group(1))
    print( "matchObj.group(2) : ", matchObj.group(2))
else:
    print("No match!!")
```
> (0, 3)
> None
> matchObj.group() :  Cats are smarter than dogs
> matchObj.group(1) :  Cats
> matchObj.group(2) :  smarter

<a name="W1HZr"></a>
### 002 re.search()
re.search 扫描整个字符串并返回**第一个成功**的匹配。<br />函数语法：

- re.search(pattern, string, flags=0)

函数参数说明：

| 参数 | 描述 |
| --- | --- |
| pattern | 匹配的正则表达式 |
| string | 要匹配的字符串。 |
| flags | 标志位，用于控制正则表达式的匹配方式，如：是否区分大小写，多行匹配等等。 |

匹配成功re.search方法返回一个匹配的对象，否则返回None。我们可以使用group(num) 或 groups() 匹配对象函数来获取匹配表达式。

| 匹配对象方法 | 描述 |
| --- | --- |
| group(num=0) | 匹配的整个表达式的字符串，group() 可以一次输入多个组号，在这种情况下它将返回一个包含那些组所对应值的元组。 |
| groups() | 返回一个包含所有小组字符串的元组，从 1 到 所含的小组号。 |

```python
import re

print(re.search('www', 'www.runoob.com').span())  # 在起始位置匹配
print(re.search('com', 'www.runoob.com').span())  # 不在起始位置匹配

line = "Cats are smarter than dogs"
matchObj = re.search(r'Cats are (.*?) than (.*?)$', line, re.M | re.I)
if matchObj:
    print("matchObj.group() : ", matchObj.group())
    print("matchObj.group(1) : ", matchObj.group(1))
    print("matchObj.group(2) : ", matchObj.group(2))
else:
    print("No match!!")
```
> (0, 3)
> (11, 14)
> matchObj.group() :  Cats are smarter than dogs
> matchObj.group(1) :  smarter
> matchObj.group(2) :  dogs

<a name="wbG1O"></a>
### 003 re.match() VS re.search()

- re.match只匹配字符串的开始，如果字符串开始不符合正则表达式，则匹配失败，函数返回None；而re.search匹配整个字符串，直到找到一个匹配。
```python
import re

line = "Cats are smarter than dogs";

matchObj = re.match(r'dogs', line, re.M | re.I)
if matchObj:
    print("match --> matchObj.group() : ", matchObj.group())
else:
    print("No match!!")

matchObj = re.search(r'dogs', line, re.M | re.I)
if matchObj:
    print("search --> searchObj.group() : ", matchObj.group())
else:
    print("No match!!")
```
> No match!!
> search --> searchObj.group() :  dogs

<a name="vbVGX"></a>
### 004 re.sub()
Python 的 re 模块提供了re.sub用于替换字符串中的匹配项。<br />语法：re.sub(pattern, repl, string, count=0, flags=0)<br />参数：

- pattern : 正则中的模式字符串。
- repl : 替换的字符串，也可为一个函数。
- string : 要被查找替换的原始字符串。
- count : 模式匹配后替换的最大次数，默认 0 表示替换所有的匹配。
```python
import re

# repl: 替换的字符串
phone = "2004-959-559 # 这是一个国外电话号码"
num = re.sub(r'#.*$', "", phone)  # 删除字符串中的 Python注释
print("电话号码是: ", num)
num = re.sub(r'\D', "", phone)    # 删除非数字(-)的字符串
print("电话号码是 : ", num)

# repl: 函数

def double(matched):              # 将匹配的数字乘以 2
    value = int(matched.group('value'))
    return str(value * 2)
s = 'A23G4HFD567'
print(re.sub('(?P<value>\d+)', double, s))

# '(?P...)' 分组匹配
s = '1102231990xxxxxxxx'
res = re.search('(?P<province>\d{3})(?P<city>\d{3})(?P<born_year>\d{4})',s)
print(res.groupdict())
```
> 电话号码是:  2004-959-559 
> 电话号码是 :  2004959559
> A46G8HFD1134
> (SimplePy) PS D:\Code\Pycharm\SimplePy> python .\test.py
> 电话号码是:  2004-959-559 
> 电话号码是 :  2004959559
> A46G8HFD1134
> {'province': '110', 'city': '223', 'born_year': '1990'}

<a name="fSaMm"></a>
### 005 re.compile()
compile 函数用于编译正则表达式，生成一个正则表达式（ Pattern ）对象，供 match() 和 search() 这两个函数使用。<br />语法格式为：<br />re.compile(pattern[, flags])<br />参数：

- **pattern** : 一个字符串形式的正则表达式
- **flags** : 可选，表示匹配模式，比如忽略大小写，多行模式等，具体参数为：
   1. **re.I** 忽略大小写
   2. **re.L** 表示特殊字符集 \w, \W, \b, \B, \s, \S 依赖于当前环境
   3. **re.M** 多行模式
   4. **re.S** 即为 **.** 并且包括换行符在内的任意字符（**.** 不包括换行符）
   5. **re.U** 表示特殊字符集 \w, \W, \b, \B, \d, \D, \s, \S 依赖于 Unicode 字符属性数据库
   6. **re.X** 为了增加可读性，忽略空格和 **#** 后面的注释
```python
>>>import re
>>> pattern = re.compile(r'\d+')                    # 用于匹配至少一个数字
>>> m = pattern.match('one12twothree34four')        # 查找头部，没有匹配
>>> print m
None
>>> m = pattern.match('one12twothree34four', 2, 10) # 从'e'的位置开始匹配，没有匹配
>>> print m
None
>>> m = pattern.match('one12twothree34four', 3, 10) # 从'1'的位置开始匹配，正好匹配
>>> print m                                         # 返回一个 Match 对象
<_sre.SRE_Match object at 0x10a42aac0>
>>> m.group(0)   # 可省略 0
'12'
>>> m.start(0)   # 可省略 0
3
>>> m.end(0)     # 可省略 0
5
>>> m.span(0)    # 可省略 0
(3, 5
```
在上面，当匹配成功时返回一个 Match 对象，其中：

- group([group1, …]) 方法用于获得一个或多个分组匹配的字符串，当要获得整个匹配的子串时，可直接使用 group() 或 group(0)；
- start([group]) 方法用于获取分组匹配的子串在整个字符串中的起始位置（子串第一个字符的索引），参数默认值为 0；
- end([group]) 方法用于获取分组匹配的子串在整个字符串中的结束位置（子串最后一个字符的索引+1），参数默认值为 0；
- span([group]) 方法返回 (start(group), end(group))。
<a name="PV8vO"></a>
### 006 re.findall()
在字符串中找到正则表达式所匹配的所有子串，并返回一个列表，如果有多个匹配模式，则返回元组列表，如果没有找到匹配的，则返回空列表。<br />**注意：** match 和 search 是匹配一次 findall 匹配所有。<br />语法格式为：<br />findall(string[, pos[, endpos]])<br />参数：

- **string** : 待匹配的字符串。
- **pos** : 可选参数，指定字符串的起始位置，默认为 0。
- **endpos** : 可选参数，指定字符串的结束位置，默认为字符串的长度。
```python
import re

# 查找字符串中的所有数字
pattern = re.compile(r'\d+')  # 查找数字
result1 = pattern.findall('runoob 123 google 456')
result2 = pattern.findall('run88oob123google456', 0, 10)
print(result1)
print(result2)

# 多个匹配模式，返回元组列表
result = re.findall(r'(\w+)=(\d+)', 'set width=20 and height=10')
print(result)
```
> ['123', '456']
> ['88', '12']
> [('width', '20'), ('height', '10')]

<a name="WtGS7"></a>
### 007 re.finditer()
和 findall 类似，在字符串中找到正则表达式所匹配的所有子串，并把它们作为一个迭代器返回。<br />re.finditer(pattern, string, flags=0)<br />参数：

| 参数 | 描述 |
| --- | --- |
| pattern | 匹配的正则表达式 |
| string | 要匹配的字符串。 |
| flags | 标志位，用于控制正则表达式的匹配方式，如：是否区分大小写，多行匹配等等。参见：[正则表达式修饰符 - 可选标志](https://www.runoob.com/python/python-reg-expressions.html#flags) |

```python
import re

it = re.finditer(r"\d+", "12a32bc43jf3")
for match in it:
    print(match.group())
```
> 12
> 32
> 43
> 3

<a name="Mstqr"></a>
### 008 re.split
split 方法按照能够匹配的子串将字符串分割后返回列表，它的使用形式如下：<br />re.split(pattern, string[, maxsplit=0, flags=0])<br />参数：

| 参数 | 描述 |
| --- | --- |
| pattern | 匹配的正则表达式 |
| string | 要匹配的字符串。 |
| maxsplit | 分隔次数，maxsplit=1 分隔一次，默认为 0，不限制次数。 |
| flags | 标志位，用于控制正则表达式的匹配方式，如：是否区分大小写，多行匹配等等。参见：[正则表达式修饰符 - 可选标志](https://www.runoob.com/python/python-reg-expressions.html#flags) |

```python
>>>import re
>>> re.split('\W+', 'runoob, runoob, runoob.')
['runoob', 'runoob', 'runoob', '']
>>> re.split('(\W+)', ' runoob, runoob, runoob.') 
['', ' ', 'runoob', ', ', 'runoob', ', ', 'runoob', '.', '']
>>> re.split('\W+', ' runoob, runoob, runoob.', 1) 
['', 'runoob, runoob, runoob.']
 
>>> re.split('a*', 'hello world')   # 对于一个找不到匹配的字符串而言，split 不会对其作出分割
['hello world']
```
<a name="d9RiH"></a>
### 009 正则表达式对象

- re.RegexObject : re.compile() 返回 RegexObject 对象。
- re.MatchObject
   - group() 返回被 RE 匹配的字符串。
      - **start()** 返回匹配开始的位置
      - **end()** 返回匹配结束的位置
      - **span()** 返回一个元组包含匹配 (开始,结束) 的位置
      <a name="zwCrv"></a>
### 010 正则表达式修饰符 - 可选标志
正则表达式可以包含一些可选标志修饰符来控制匹配的模式。修饰符被指定为一个可选的标志。多个标志可以通过按位 OR(|) 它们来指定。如 re.I | re.M 被设置成 I 和 M 标志：

| 修饰符 | 描述 |
| --- | --- |
| re.I | 使匹配对大小写不敏感 |
| re.L | 做本地化识别（locale-aware）匹配 |
| re.M | 多行匹配，影响 ^ 和 $ |
| re.S | 使 . 匹配包括换行在内的所有字符 |
| re.U | 根据Unicode字符集解析字符。这个标志影响 \\w, \\W, \\b, \\B. |
| re.X | 该标志通过给予你更灵活的格式以便你将正则表达式写得更易于理解。 |

<a name="aq7Gr"></a>
### 011 正则表达式模式
模式字符串使用特殊的语法来表示一个正则表达式：<br />字母和数字表示他们自身。一个正则表达式模式中的字母和数字匹配同样的字符串。<br />多数字母和数字前加一个反斜杠时会拥有不同的含义。<br />标点符号只有被转义时才匹配自身，否则它们表示特殊的含义。<br />反斜杠本身需要使用反斜杠转义。<br />由于正则表达式通常都包含反斜杠，所以你最好使用原始字符串来表示它们。模式元素(如 r'\t'，等价于 '\\t')匹配相应的特殊字符。<br />下表列出了正则表达式模式语法中的特殊元素。如果你使用模式的同时提供了可选的标志参数，某些模式元素的含义会改变。

| 模式 | 描述 |
| --- | --- |
| ^ | 匹配字符串的开头 |
| $ | 匹配字符串的末尾。 |
| . | 匹配任意字符，除了换行符，当re.DOTALL标记被指定时，则可以匹配包括换行符的任意字符。 |
| [...] | 用来表示一组字符,单独列出：[amk] 匹配 'a'，'m'或'k' |
| [^...] | 不在[]中的字符：[^abc] 匹配除了a,b,c之外的字符。 |
| re* | 匹配0个或多个的表达式。 |
| re+ | 匹配1个或多个的表达式。 |
| re? | 匹配0个或1个由前面的正则表达式定义的片段，非贪婪方式 |
| re{ n} | 精确匹配 n 个前面表达式。例如， **o{2}** 不能匹配 "Bob" 中的 "o"，但是能匹配 "food" 中的两个 o。 |
| re{ n,} | 匹配 n 个前面表达式。例如， o{2,} 不能匹配"Bob"中的"o"，但能匹配 "foooood"中的所有 o。"o{1,}" 等价于 "o+"。"o{0,}" 则等价于 "o*"。 |
| re{ n, m} | 匹配 n 到 m 次由前面的正则表达式定义的片段，贪婪方式 |
| a&#124; b | 匹配a或b |
| (re) | 对正则表达式分组并记住匹配的文本 |
| (?imx) | 正则表达式包含三种可选标志：i, m, 或 x 。只影响括号中的区域。 |
| (?-imx) | 正则表达式关闭 i, m, 或 x 可选标志。只影响括号中的区域。 |
| (?: re) | 类似 (...), 但是不表示一个组 |
| (?imx: re) | 在括号中使用i, m, 或 x 可选标志 |
| (?-imx: re) | 在括号中不使用i, m, 或 x 可选标志 |
| (?#...) | 注释. |
| (?= re) | 前向肯定界定符。如果所含正则表达式，以 ... 表示，在当前位置成功匹配时成功，否则失败。但一旦所含表达式已经尝试，匹配引擎根本没有提高；模式的剩余部分还要尝试界定符的右边。 |
| (?! re) | 前向否定界定符。与肯定界定符相反；当所含表达式不能在字符串当前位置匹配时成功 |
| (?> re) | 匹配的独立模式，省去回溯。 |
| \\w | 匹配字母数字及下划线 |
| \\W | 匹配非字母数字及下划线 |
| \\s | 匹配任意空白字符，等价于 **[ \\t\\n\\r\\f]**。 |
| \\S | 匹配任意非空字符 |
| \\d | 匹配任意数字，等价于 [0-9]. |
| \\D | 匹配任意非数字 |
| \\A | 匹配字符串开始 |
| \\Z | 匹配字符串结束，如果是存在换行，只匹配到换行前的结束字符串。 |
| \\z | 匹配字符串结束 |
| \\G | 匹配最后匹配完成的位置。 |
| \\b | 匹配一个单词边界，也就是指单词和空格间的位置。例如， 'er\\b' 可以匹配"never" 中的 'er'，但不能匹配 "verb" 中的 'er'。 |
| \\B | 匹配非单词边界。'er\\B' 能匹配 "verb" 中的 'er'，但不能匹配 "never" 中的 'er'。 |
| \\n, \\t, 等. | 匹配一个换行符。匹配一个制表符。等 |
| \\1...\\9 | 匹配第n个分组的内容。 |
| \\10 | 匹配第n个分组的内容，如果它经匹配。否则指的是八进制字符码的表达式。 |

<a name="M3VcV"></a>
### 012 正则表达式实例
<a name="ocFIq"></a>
#### 字符匹配
| 实例 | 描述 |
| --- | --- |
| python | 匹配 "python". |

<a name="Oybpx"></a>
#### 字符类
| 实例 | 描述 |
| --- | --- |
| [Pp]ython | 匹配 "Python" 或 "python" |
| rub[ye] | 匹配 "ruby" 或 "rube" |
| [aeiou] | 匹配中括号内的任意一个字母 |
| [0-9] | 匹配任何数字。类似于 [0123456789] |
| [a-z] | 匹配任何小写字母 |
| [A-Z] | 匹配任何大写字母 |
| [a-zA-Z0-9] | 匹配任何字母及数字 |
| [^aeiou] | 除了aeiou字母以外的所有字符 |
| [^0-9] | 匹配除了数字外的字符 |

<a name="bcPHm"></a>
#### 特殊字符类
| 实例 | 描述 |
| --- | --- |
| . | 匹配除 "\\n" 之外的任何单个字符。要匹配包括 '\\n' 在内的任何字符，请使用象 '[.\\n]' 的模式。 |
| \\d | 匹配一个数字字符。等价于 [0-9]。 |
| \\D | 匹配一个非数字字符。等价于 [^0-9]。 |
| \\s | 匹配任何空白字符，包括空格、制表符、换页符等等。等价于 [ \\f\\n\\r\\t\\v]。 |
| \\S | 匹配任何非空白字符。等价于 [^ \\f\\n\\r\\t\\v]。 |
| \\w | 匹配包括下划线的任何单词字符。等价于'[A-Za-z0-9_]'。 |
| \\W | 匹配任何非单词字符。等价于 '[^A-Za-z0-9_]'。 |

<a name="tbHzd"></a>
## 01 JSON 数据处理
<a name="RgDHF"></a>
### 001 JSON基础
> **什么是JSON？**

1. JSON是一种轻量级数据交互格式，采用完全独立于编程语言的文本格式来存储和表示数据。和xml相比，它更小巧，但描述能力却不差，更适合在网络上传输数据。
2. JSON是一种有着特殊格式的字符串，格式与对象或者数组是非常类似的，只不过属性名是带双引号的。
3. JSON用于对象和数组的序列化。(序列化:格式转换）用于对象和数组与字符串进行相互转换。
> **JSON的使用**

- Python3 中可以使用 json 模块来对 JSON 数据进行编解码，它包含了两个函数：
   - json.dumps(): 对数据进行编码。
   - json.loads(): 对数据进行解码。

![image.png](https://cdn.nlark.com/yuque/0/2022/png/26699051/1669901399478-2a042b66-1a99-4f45-a795-5cf1c04950ce.png#averageHue=%23f4f4f4&clientId=u0cd6b864-4cda-4&crop=0&crop=0&crop=1&crop=1&from=paste&height=307&id=u2e395454&margin=%5Bobject%20Object%5D&name=image.png&originHeight=307&originWidth=518&originalType=binary&ratio=1&rotation=0&showTitle=false&size=20709&status=done&style=none&taskId=u1161de2b-0b88-4377-8769-47258469611&title=&width=518)

- **Python 编码为 JSON 类型转换对应表：**

![image.png](https://cdn.nlark.com/yuque/0/2022/png/26699051/1669901458668-05ab215e-f930-4023-b792-11a48db632f0.png#averageHue=%23e9e8e6&clientId=u0cd6b864-4cda-4&crop=0&crop=0&crop=1&crop=1&from=paste&height=275&id=u951d5edd&margin=%5Bobject%20Object%5D&name=image.png&originHeight=275&originWidth=592&originalType=binary&ratio=1&rotation=0&showTitle=false&size=14855&status=done&style=none&taskId=uab796250-89fa-4248-85d4-9f4530c44aa&title=&width=592)

- **JSON 解码为 Python 类型转换对应表：**

![image.png](https://cdn.nlark.com/yuque/0/2022/png/26699051/1669901486889-bb09013d-205f-4614-9096-9ee1fcbe7cd1.png#averageHue=%23ecebe9&clientId=u0cd6b864-4cda-4&crop=0&crop=0&crop=1&crop=1&from=paste&height=308&id=u36410d21&margin=%5Bobject%20Object%5D&name=image.png&originHeight=308&originWidth=581&originalType=binary&ratio=1&rotation=0&showTitle=false&size=13716&status=done&style=none&taskId=u79711096-cfb3-4c04-9ac4-97b225f0ddf&title=&width=581)
<a name="hr72L"></a>
### 002 处理 JSON 数据
```python
import json

# Python 字典类型转换为 JSON 对象
data1 = {
    'no': 1,
    'name': 'C君莫笑',
    'url': 'https://blog.csdn.net/qq_34623621?type=blog'
}

json_str = json.dumps(data1)

# repr() 是python的内置函数, 将对象转化为供解释器读取的形式, repr(object), 返回一个对象的string格式。
print("Python 原始数据：", repr(data1))
print("JSON 对象：", json_str)

# 将 JSON 对象转换为 Python 字典
data2 = json.loads(json_str)
print("data2['name']: ", data2['name'])
print("data2['url']: ", data2['url'])
```
<a name="jXt97"></a>
### 003 处理 JSON 文件
```python
import json

# 写入 JSON 数据
data1 = {
    'no': 1,
    'name': 'C君莫笑',
    'url': 'https://blog.csdn.net/qq_34623621?type=blog'
}

with open('data.json', 'w') as f:
    json.dump(data1, f)

# 读取数据
with open('data.json', 'r') as f:
    data = json.load(f)
    # 输出JSON数据
    print(data)
    print(data['name'])
```
<a name="VUJGO"></a>
## 02 Excel 数据处理
<a name="z8MrO"></a>
### 000 安装 pandas 库
```python
pip install pandas
pip install openpyxl
```
<a name="EPHzl"></a>
### 001 简介 pandas 库
在Python中，pandas是基于NumPy数组构建的，使数据预处理、清洗、分析工作变得更快更简单。pandas是专门为处理表格和混杂数据设计的，而NumPy更适合处理统一的数值数组数据。<br />pandas有两个主要数据结构：Series和DataFrame。

- Series : 是一种类似于一维数组的对象，它由一组数据（各种NumPy数据类型）以及一组与之相关的数据标签（即索引）组成，即index和values两部分，可以通过索引的方式选取Series中的单个或一组值。
- DataFrame : DataFrame是一个表格型的数据类型，每列值类型可以不同，是最常用的pandas对象。DataFrame既有行索引也有列索引，它可以被看做由Series组成的字典（共用同一个索引）。DataFrame中的数据是以一个或多个二维块存放的（而不是列表、字典或别的一维数据结构）
<a name="D46Xk"></a>
### 002 使用 pandas 库
<a name="rf4O1"></a>
#### 00 导入 pandas 库
```python
import numpy as np
import pandas as pd
```
<a name="auGTO"></a>
#### 01 写入excel 文件
```python
# -*- coding: utf-8 -*-
import pandas as pd
 
 
def pd_toExcel(data, fileName):  # pandas库储存数据到excel
    ids = []
    names = []
    prices = []
    for i in range(len(data)):
        ids.append(data[i]["id"])
        names.append(data[i]["name"])
        prices.append(data[i]["price"])
 
    dfData = {  # 用字典设置DataFrame所需数据
        '序号': ids,
        '酒店': names,
        '价格': prices
    }
    df = pd.DataFrame(dfData)  # 创建DataFrame
    df.to_excel(fileName, index=False)  # 存表，去除原始索引列（0,1,2...）
 
 
# "-------------数据用例-------------"
testData = [
    {"id": 1, "name": "立智", "price": 100},
    {"id": 2, "name": "维纳", "price": 200},
    {"id": 3, "name": "如家", "price": 300},
]
fileName = '测试2.xlsx'
pd_toExcel(testData, fileName)
```
<a name="BSJ1d"></a>
## 03 HTML 数据处理
<a name="uIhDr"></a>
### 001 安装 BeautifulSoup 库
```python
# 安装BeautifulSoup
pip3 install beautifulsoup4

# 安装第三方html解析器lxml
pip3 install lxml

# 安装纯Python实现的html5lib解析器
pip3 install html5lib
```
<a name="sCiCj"></a>
### 002 使用 BeautifulSoup 库
<a name="mdZoo"></a>
#### 00 创建BeautifulSoup对象
```python
# （1）直接通过字符串方式创建
soup= BeautifulSoup(html_str,"lxml")                                  # html.parser是解析器，也可是lxml
print(soup.prettify())                                                # 输出soup对象的内容

#（2）通过已有的文件来创建
soup= BeautifulSoup(open("/home/index.html"),features="html.parser")  # html.parser是解析器，也可是lxml
```
<a name="guzXp"></a>
#### 01 BS4 四大对象种类

- Beautiful Soup将复杂HTML文档转换成一个复杂的[树形结构](https://so.csdn.net/so/search?q=%E6%A0%91%E5%BD%A2%E7%BB%93%E6%9E%84&spm=1001.2101.3001.7020),每个节点都是Python对象,所有对象可以归纳为4种:
   - Tag
   - NavigableString
   - [BeautifulSoup](https://so.csdn.net/so/search?q=BeautifulSoup&spm=1001.2101.3001.7020)
   - Comment
```python
import bs4
from bs4 import BeautifulSoup

html_str = """
<html>
    <head><title >TheDormouse"s story</title></head>
<body>
    <p class="title"><b>The Dormouse"s stopy</b></p>
    <p class="story">Once upon a time there were three littlesisters;and their names where</p>
    <a href="http://example.com/elsie" class="sister" id="link1"><!--It's a a tag!!!--></a>
</body>
</html>
"""
# 创建BeautifulSoup对象
# soup= BeautifulSoup(open("/home/index.html"),features="html.parser")
soup = BeautifulSoup(html_str, "lxml")        # html.parser是解析器，也可是lxml
print(soup.prettify())

# Tag对象
## 获取标签
print(soup.a)

## 输出标签的标签类型名
print(soup.title.name)

## 获取标签attributess属性，操作Tag属性的方法和操作字典相同
print(soup.a.attrs)           # 获取a标签所有属性
print(soup.a['href'])         # 只获取a标签 href 属性
print(soup.a.get('class'))    # 只获取a标签 Class 属性

## 修改Tag对象属性
soup.a['href'] = "test.com"
print(soup.a)

## 删除Tag对象属性
del soup.a['class']
print(soup.a)

# NavigableString：获取标记内部的文字.string
print(soup.a.string)

# 一个NavigableString字符串与Python中的Unicode字符串相同，通过str()方法可以直接将NavigableString对象转换成Unicode字符串
# 在Python 3中，unicode()已重命名为str()
u_string = str(soup.a.string)
print(u_string)


# BeautifulSoup 文档对象，也就是整个文档的内容。可以当做是一个Tag对象。
print(soup.name)
print(type(soup.name))

# Coment对象是一个特殊类型的NavigableString对象。
# 如果标签内部的内容是注释，例如：<!-- Elsie -->。那么该NavigableSring对象会转换成Comment对象，并且会把注释符号去掉。
# Comment：对于一些特殊对象，如果不清楚这个标记.string的情况下，可能造成数据提取混乱。因此在提取字符串时，可以判断下类型：
print(type(soup.a.string))
if type(soup.a.string) == bs4.element.Comment:
    print(soup.a.string)
```
<a name="c4tLo"></a>
#### 02 遍历文档树
```python
from bs4 import BeautifulSoup

html_str = """
<html>
    <head><title >TheDormouse"s story</title></head>
<body>
    <p class="title"><b>The Dormouse"s stopy</b></p>
    <p class="story">Once upon a time there were three littlesisters;and their names where</p>
    <a href="http://example.com/elsie" class="sister" id="link1"><!--It's a a tag!!!--></a>
</body>
</html>
"""
# 创建BeautifulSoup对象
# soup= BeautifulSoup(open("/home/index.html"),features="html.parser")
soup = BeautifulSoup(html_str, "lxml")        # html.parser是解析器，也可是lxml

# 直接子节点
## (1) .contents Tag对象的.contents属性可以将某个tag的子节点以列表的方式输出,当然列表会允许用索引的方式来获取列表中的元素。
print(soup.body.contents)
print(soup.body.contents[1])   # 注意'\n' 也算
print(soup.body.contents[3])

## (2) .children Tag对象的children属性是一个迭代器
print(soup.body.children)
for child in soup.body.children:
    print(child)

# 所有子孙结点 .descendants属性 与Tag对象的children和contents仅包含Tag对象的直接子节点不同，该属性是将Tag对象的所有子孙结点进行递归循环，然后生成生成器
print(soup.body.descendants)
for child in soup.body.descendants:
    print(child)


# 结点内容
## (1) Tag对象内没有标签的情况
print(soup.title)
print(soup.title.string)

## (2) Tag对象内有一个标签的情况
print(soup.head)
print(soup.head.string)

## (3) Tag对象内有多个标签的情况, 仍然使用string是不可行的, 应该使用.strings属性或.stripped_strings，他们获得的都是一个生成器。
print(soup.strings)
for string in soup.strings:
    print(string)

print(soup.stripped_strings)  # 使用Tag对象的.stripped_strings属性获得去掉空白行的标签内的众多内容。
for string in soup.stripped_strings:
    print(string)

# 直接父节点
## (1) 标签的父节点
print(soup.title)
print(soup.title.parent.name)

## (2) 内容的父节点：是包在内容外的第一层标签
content = soup.head.title.string
print(content)
print(content.parent.name)

# 全部父节点
## .parents属性，得到的也是一个生成器
content = soup.head.title.string
print(content)
for parent in content.parents:
    print(parent.name)

# 兄弟结点
## .next_sibling和.previous_sibling属性分别是获取下一个兄弟结点和获取上一个兄弟结点。
## 通常情况下，使用这两个属性会得到空白或者换行。因为beautifulsoup会将空白和换行识别成一个结点
print(soup.p.next_sibling)
print(soup.a.previous_sibling)
print(soup.p.next_sibling.next_sibling)

# 全部兄弟结点
## .next_siblings和.previous_siblings可以对当前的兄弟结点迭代输出
for next in soup.a.previous_siblings:
    print(next)


# 前后元素
## .next_element和.previous_element属性，是获得不分层次的前后元素（同一层的才叫兄弟结点）
#  所有前后元素
## .next_elements和.previous_elements属性可以向前或向后解析文档内容
for element in soup.a.previous_elements:
    print(repr(element))
```
<a name="mZ7D1"></a>
#### 03 搜索文档树
<a name="XgsAH"></a>
##### 1. find_all()
> 1. 使用方法：find_all(name,attrs,recursive,text,**kwargs)
> 2. 搜索范围：当前tag的所有tag子节点。
> 3. 作用：判断当前tag的所有tag子节点是否符合过滤器的条件。
> 4. name参数：**查找**所有名字为name的**tag**，字符串会被自动忽略掉。

- 传入字符串
- 传入正则表达式
- 传入列表
- 传入True：找到所有的Tag
- 传入方法：自行构造过滤器，方法的参数是tag对象，返回值是Ture | False。
- keyword参数
   - 通过name参数是搜索tag的标签类型名称，如a、head、title。
   - 如果要通过标签内属性的值来搜索，要通过键值对的形式来指定。例如:soup_findall(id='link2')。
- text参数
   - 作用和name参数类似，但是text参数的搜索范围是**文档中的字符串内容（不包含注释）**，并且**是完全匹配**，当然也接受正咋表达式、列表、True。
- limit参数
   - 可以通过limit参数来限制使用name参数或者attr参数过滤出来的条目的数量。
- recuresive参数
   - 通常情况下使用find_all方法时，会返回
```python
from bs4 import BeautifulSoup
import re

html_str = """
<html>
    <head><title >TheDormouse"s story</title></head>
<body>
    <p class="title"><b>The Dormouse"s stopy</b></p>
    <p class="story">Once upon a time there were three littlesisters;and their names where</p>
    <a href="http://example.com/elsie" class="sister" id="link1"><!--It's a a tag!!!--></a>
</body>
</html>
"""
# 创建BeautifulSoup对象
# soup= BeautifulSoup(open("/home/index.html"),features="html.parser")
soup = BeautifulSoup(html_str, "lxml")        # html.parser是解析器，也可是lxml

# 1. 传入字符串
print(soup.find_all('a'))

# 2. 传入正则表达式
for tag in soup.find_all(re.compile("^b")):
    print(tag)

# 3. 传入列表
print(soup.find_all(["a","b"]))

# 4. 传入True
for tag in soup.find_all(True):
    print(tag.name)

# 5. 传入方法
def has_class_but_no_id(tag):
    return tag.has_attr('class') and not tag.has_attr('id')

print(soup.find_all(has_class_but_no_id))

# 6. keyword参数
## 如果要通过标签内属性的值来搜索，要通过键值对的形式来指定。例如:soup_findall(id='link2')。
print(soup.find_all(id='link1'))
print(soup.find_all(href=re.compile("elsie")))

## 如果指定的key是python的内置参数，后面需要加下划线，例如class_=“sister”
print(soup.find_all(class_="sister"))

## html5的data-*属性是无法用来直接指定的，可以通过attr参数自定义参数字典：soup.find_all(attrs={"data-foo":"value"})
data_soup = BeautifulSoup('<div data-foo="value">foo!</div>',features="lxml")
print(data_soup.find_all(attrs={"data-foo":"value"}))

# 7. text参数
## 作用和name参数类似，但是text参数的搜索范围是文档中的字符串内容（不包含注释），并且是完全匹配，当然也接受正咋表达式、列表、True
print(soup.a)
print(soup.find_all(text="The Dormouse s stopy"))
print(soup.find_all(text=["Tillie", "upon", "Lacie"]))
print(soup.find_all(text="The Dormouse's story"))
print(soup.find_all(text=re.compile("time")))

# 8. limit参数
## 可以通过limit参数来限制使用name参数或者attr参数过滤出来的条目的数量。
print(soup.find_all("p"))
print("===============")
print(soup.find_all("p", limit=1))

# 9. recuresive参数
## 通常情况下使用find_all方法时，会返回
print(soup.body)
print("===============================")
print(soup.body.find_all("a", recursive=False))
print(soup.body.find_all("a"))
```
<a name="J0zvI"></a>
##### 2. find

- 使用方法：find(name,attrs,recursive,text,**kwargs)
- 与find_all的区别：find_all将所有匹配的条目组合成一个列表，而find仅返回第一个匹配的条目。
- 除此之外，用法相同
```python
from bs4 import BeautifulSoup

html_str = """
<html>
    <head><title >TheDormouse"s story</title></head>
<body>
    <p class="title"><b>The Dormouse"s stopy</b></p>
    <p class="story">Once upon a time there were three littlesisters;and their names where</p>
    <a href="http://example.com/elsie" class="sister" id="link1"><!--It's a a tag!!!--></a>
</body>
</html>
"""
# 创建BeautifulSoup对象
# soup= BeautifulSoup(open("/home/index.html"),features="html.parser")
soup = BeautifulSoup(html_str, "lxml")        # html.parser是解析器，也可是lxml

print(soup.body.find_all("p"))
print(soup.body.find("p"))
```
<a name="VhBG3"></a>
##### 3. find_parents / find_parent

- find_all()和find()搜索的范围是当前节点的所有子孙节点（recursive默认的情况下）。
- 而find_parents和find_parent的搜索范围则是当前节点的父节点。
- 两个函数的特性和其他用法与上面所述相同。
```python
from bs4 import BeautifulSoup

html_str = """
<html>
    <head><title >TheDormouse"s story</title></head>
<body>
    <p class="title"><b>The Dormouse"s stopy</b></p>
    <p class="story">Once upon a time there were three littlesisters;and their names where</p>
    <a href="http://example.com/elsie" class="sister" id="link1"><!--It's a a tag!!!--></a>
</body>
</html>
"""
# 创建BeautifulSoup对象
# soup= BeautifulSoup(open("/home/index.html"),features="html.parser")
soup = BeautifulSoup(html_str, "lxml")        # html.parser是解析器，也可是lxml

print(soup.body.find_all("p"))
print(soup.body.find("p"))
print(soup.body.find_parents("a"))
print(soup.body.find_parents("html"))
```
<a name="Z4ECX"></a>
##### 4.Other

- find_next_siblings和find_next_sibling
   - 搜索范围是当前结点后面的兄弟结点。
   - 其他特性和用法与上面的完全相同。
- find_previous_siblings和find_previous_sibling
   - 搜索范围是当前结点前面的兄弟结点。
   - 其他特性和用法与上面的完全相同。
- find_all_next和find_next
   - 搜索范围是当前结点后面的结点或字符串。
   - 其他特性和用法与上面的完全相同
- find_all_previous和find_previous
   - 搜索范围是当前结点前面的结点或字符串。
   - 其他特性和用法与上面的完全相同
   <a name="WSdc3"></a>
#### 04 CSS 选择器
```python
from bs4 import BeautifulSoup
import re

html_str = """
<html>
    <head><title >TheDormouse"s story</title></head>
<body>
    <p class="title"><b>The Dormouse"s stopy</b></p>
    <p class="story">Once upon a time there were three littlesisters;and their names where</p>
    <a href="http://example.com/elsie" class="sister" id="link1"><!--It's a a tag!!!--></a>
</body>
</html>
"""
# 创建BeautifulSoup对象
# soup= BeautifulSoup(open("/home/index.html"),features="html.parser")
soup = BeautifulSoup(html_str, "lxml")        # html.parser是解析器，也可是lxml

# 1. 通过标签名查找
print(soup.select('title'))
print(soup.select('b'))

# 2. 通过类名查找
print(soup.select('.story'))

# 3. 通过id名查找
print(soup.select('#link1')[0])

# 4. 组合查找
## 后代选择器 连接标识符： 空格
## 儿子选择器 连接标识符： >
## 毗邻选择器 连接标识符： +
## 弟弟选择器 连接标识符： ~
## 多个过滤条件需要用空格隔开,从前往后是逐层筛选，选择器作用的不是 同一个结点。
print(soup.select('body >.story'))


# 5. 属性查找
#print(soup.select('p >a'))
print(soup.select('[href="http://example.com/elsie"]'))

# 6. 列表迭代
# 通过上述方法返回的都是列表，是可迭代对象。
print(soup.select('body >a'))
print(type(soup.select('body >a')))
print("====")
print(soup.select('body >a')[0])
print("====")
for a in soup.select('body >a'):
    print(a)
```
<a name="axawn"></a>
### 003 XPATH 选择器

- xpath作为一种HTML专用的解析语法。可以快速的定位内容。相当于HTML的正则表达式。
- 和前一节的bs4爬取信息的思路是差不多的，但是方式和形式上看上去有不小的差异。
<a name="xk6Is"></a>
#### 00  构建文档树

- 使用时先安装 lxml 包
```python
html_str = """
<html>
    <head><title >TheDormouse"s story</title></head>
<body>
    <p class="title"><b>The Dormouse"s stopy</b></p>
    <p class="story">Once upon a time there were three littlesisters;and their names where</p>
    <a href="http://example.com/elsie" class="sister" id="link1"><!--It's a a tag!!!--></a>
</body>
</html>
"""
from lxml import etree

# 读取外部文件 index.html
# html = etree.parse('./index.html')
# parse读取, tostring将etree的文档节点对象转化为文本字符串。
html = etree.parse(html_str)
result = etree.tostring(html, pretty_print=True)    # pretty_print=True 会格式化输出
print(result)
```

- 不过一般上游不是本地的HTML，而是response返回的text。
```python
html  = etree.HTML(html_text)
result = etree.tostring(html,encoding="gbk")
print(str(result,'gbk')) # 相当于decode
```

- 根据我们的实例,需要这么处理,不然又回乱码了…
- 很多教程是utf-8.但是对于我们的实例是不对的.因为其他人的教程都是内部的格式字符串,自然是utf-8
- 但是更多的中文网页的情形却不是,尤其是文本含量比较多的网站.
<a name="L4eD2"></a>
#### 01 xpath 语法

- xpath的语法也是**递归的**.也就是说返回的还是一个可以解析的文本节点对象.
- 这与前面的bs4和find是一个逻辑.
- 返回的是一个对象的列表.
```python
r_list = parse_html.xpath('xpath表达式') 
```

- 语法元素
```python
表达式	描述
nodename	选取此节点的所有子节点
/	从当前节点选取直接子节点
//	从当前节点选取子孙节点
.	选取当前节点
..	选取当前节点的父节点
@	选取属性
*	通配符，选择所有元素节点与元素名
@*	选取所有属性
[@attrib]	选取具有给定属性的所有元素
[@attrib='value']	选取给定属性具有给定值的所有元素
[tag]	选取所有具有指定元素的直接子节点
[tag='text']	选取所有具有指定元素并且文本内容是text节点
```
<a name="gNSKQ"></a>
#### 02 实例讲解
```python
html.xpath('//li')   #获取所有子孙节点的li节点
html.xpath('//li/a')   #获取所有子孙节点的li节点的直接子节点a
html.xpath('//book|//cd') #代表这两个的集合

# 属性限定,不限于class
html.xpath('//li/a[@href]')   #获取所有子孙节点的li节点的直接子节点a,但href要求含有href这个属性
html.xpath('//li/a[@href="link2.html"]')   #获取所有子孙节点的li节点的直接子节点a,但href要求为指定值，要求完全匹配
# 多个属性值类如class="aaa bbb"，使用contains()，部分匹配
html.xpath('//li/a[contains(@class,"aaa")]')
# 多个属性筛选器用and或者or逻辑运算。
result1=html.xpath('//li[contains(@class,"aaa") and @name="fore"]/a/text()')
# 含有整数值的筛选器
html.xpath('//li/a[@num>10]') 
html.xpath('//li/a[@num1>10 and @num2]') 

# 获取class的值，不限于class
html.xpath('//li/a[@href="link2.html"]/@class')
# 文本获取
html.xpath('//li/a[@href="link2.html"]/text()')
```

- 注意：如果是直接的子元素html.xpath(‘a’) ，无需再加/.或者写成xpath(‘./a’)。html.xpath(‘/a’) 指的是孙子节点a。
- 所以大致分为三个步骤：
   1. 用//大步长跳转，/小步长跳转定位到tag
   2. 使用属性限定得到目标地元素集合
   3. 提取文本信息
   <a name="NmQBk"></a>
## 04 字符串 数据处理

- [https://blog.csdn.net/cpxsxn/article/details/125161162](https://blog.csdn.net/cpxsxn/article/details/125161162)
- 格式化字符串字面值
   - 当我们在一个字符串前标注一个'f'或'F'时，Python解释器就认为这个字符串是一个**格式化字符串字面值**。在这个字符串中使用“{}”将一个变量或表达式括起来，Python就会用变量或表达式的内容替换“{}”。格式化字符串字面值还可以使用**格式说明符**，用法与str.format相同：
```powershell
price = 12.567
print(f"苹果的价格是{price:.2f}") # 苹果的价格是12.57	
```
```
my_str = "hello world"
my_str_as_bytes = str.encode(my_str)
print(type(my_str_as_bytes)) # ensure it is byte representation
my_decoded_str = my_str_as_bytes.decode()
print(type(my_decoded_str)) # ensure it is string representation
```

<a name="CmFNv"></a>

# 0x04 编码转换
<a name="akYOt"></a>
## 00 Base64

- 安装 Base64 库
```bash
pip install pybase64
```

- 对 字符串 b64encode &  b64decode
```python
import base64

st = 'hello world!'.encode()            # 默认以utf8编码
# st = 'hello world!'.encode('utf-8')
res = base64.b64encode(st)
print(res.decode())                     # 默认以utf8解码
res = base64.b64decode(res)
print(res.decode())                     
# print(res.decode(encoding='utf-8'))   
```

- 对 任意文件 b64encode &  b64decode 
```python
import base64

def ToBase64(file, txt):
    with open(file, 'rb') as fileObj:
        image_data = fileObj.read()
        base64_data = base64.b64encode(image_data)
        fout = open(txt, 'w')
        fout.write(base64_data.decode())
        fout.close()


def ToFile(txt, file):
    with open(txt, 'r') as fileObj:
        base64_data = fileObj.read()
        ori_image_data = base64.b64decode(base64_data)
        fout = open(file, 'wb')
        fout.write(ori_image_data)
        fout.close()

ToBase64("./1.txt",'desk_base64.txt')  # 文件转换为base64
ToFile("./desk_base64.txt", 'n1.txt')  # base64编码转换为二进制文件
```
<a name="AV2rA"></a>
# 0x05 加密解密

- [https://blog.csdn.net/lly1122334/article/details/125134528](https://blog.csdn.net/lly1122334/article/details/125134528)
- pycryptodome 库
- PyCryptodome是PyCrypto的一个分支。基于PyCrypto2.6.1
- [pycrypto](https://github.com/pycrypto/pycrypto) 实现了[哈希](https://so.csdn.net/so/search?q=%E5%93%88%E5%B8%8C&spm=1001.2101.3001.7020)函数（如 SHA256）和加密算法（如 AES、DES、RSA）。注意！[pycrypto](https://github.com/pycrypto/pycrypto) 已很久未维护，有安全漏洞。建议使用 [pycryptodome](https://github.com/Legrandin/pycryptodome) 替代 [pycrypto](https://github.com/pycrypto/pycrypto)，它是后者的一个分支，一直在维护。
```python
pip install pycryptodome
```
<a name="IffG7"></a>
# 0x06 命令执行
<a name="yMj1F"></a>
### 000 os.system()

- 在子终端运行系统命令，可以获取命令执行后的返回信息以及执行返回的状态
```python
import os
os.system('ipconfig')
```
<a name="lrQau"></a>
### 001 **os.popen()**

- 不仅执行命令而且返回执行后的信息对象(常用于需要获取执行命令后的返回信息)，是通过一个管道文件将结果返回
```python
import os
cmdres = os.popen('ipconfig')
print(cmdres.read())
```
<a name="uCP0Y"></a>
### 002 **subprocess 模块**

- 运用对线程的控制和监控，将返回的结果赋于一变量，便于程序的处理。有丰富的参数可以进行配置，可供我们自定义的选项多，灵活性高。之前我使用os.system的时候遇到文件描述符被子进程继承的问题，后来通过close_fds = False 这个参数来解决的。
- 官方文档：[http://python.usyiyi.cn/python_278/library/subprocess.html]()
```python
import subprocess
cmdres = subprocess.Popen('whoami', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
print("cmdres: {}\n".format(cmdres.stdout.read()))
```
<a name="Oq7De"></a>
# 0x07 多线程

- [https://www.cnblogs.com/fjfsu/p/15709155.html](https://www.cnblogs.com/fjfsu/p/15709155.html)
<a name="uuBXh"></a>
## 线程池
```python
import time
from concurrent.futures import ThreadPoolExecutor  # 并行期货，线程池执行者
"""
pool = ThreadPoolExecutor(100)
pool.submit(函数名,参数1，参数2，参数...)
"""


def task(video_url, num):
    print("开始执行任务", video_url, num)     # 开始执行任务 www.xxxx-299.com 3
    time.sleep(1)


# 创建线程池，最多维护10个线程
threadpool = ThreadPoolExecutor(10)
# 生成300网址，并放入列表
url_list = ["www.xxxx-{}.com".format(i) for i in range(300)]
for url in url_list:
    """
    在线程池中提交一个任务，线程池如果有空闲线程，则分配一个线程去执行，执行完毕后在将线程交还给线程池，
    如果没有空闲线程，则等待。注意在等待时，与主线程无关，主线程依然在继续执行。
    """
    threadpool.submit(task, url, 3)

print("等待线程池中的任务执行完毕中······")
threadpool.shutdown(True)   # 等待线程池中的任务执行完毕后，在继续执行
print("END")
```
```python
"""线程池的回调"""
import time
import random
from concurrent.futures import ThreadPoolExecutor


def task(video_url):
    print("开始执行任务", video_url)
    time.sleep(1)
    return random.randint(0, 10)    # 将结果封装成一个Futuer对象，返回给线程池


def done(response):     # response就是futuer对象，也就是task的返回值分装的一个Futuer对象
    print("任务执行完后，回调的函数", response.result())    # 即Futuer.result()：取出task的返回值


# 创建线程池
threadpool = ThreadPoolExecutor(10)
url_list = ["www.xxxx-{}.com".format(i) for i in range(5)]
for url in url_list:
    futuer = threadpool.submit(task, url)    # futuer是由task返回的一个Future对象，里面有记录task的返回值
    futuer.add_done_callback(done)           # 回调done函数，执行者依然是子线程

# 优点：可以做分工，例如：task专门下载，done专门将下载的数据写入本地文件。
```
<a name="Q6b7L"></a>
# 0x08 异步

- [https://zhuanlan.zhihu.com/p/242799683](https://zhuanlan.zhihu.com/p/242799683)
```python
#!/usr/bin/env python3
import asyncio,random,time

async def foo():
    await asyncio.sleep(random.randint(1,8)/10.0)
    end=time.time()
    print(f"foo()耗时{end-start}秒")
    return 101

async def foo2():
    await asyncio.sleep(random.randint(1,8)/10.0)
    end=time.time()
    print(f"foo2()耗时{end-start}秒")
    return 102

async def foo3():
    await asyncio.sleep(random.randint(1,8)/10.0)
    end=time.time()
    print(f"foo3()耗时{end-start}秒")
    return 103

async def main():
    R=[foo(),foo2(),foo3()]
    await asyncio.gather(*R)

if __name__ == "__main__":
    start=time.time()
    asyncio.run(main())

    end=time.time()
    print(f"__main__耗时{end-start}秒")
```
<a name="cYrdA"></a>
# 0x09 命令行参数

- **argparse** 库是python自带库，不用特殊安装
- **argparse **用于使用python构建工具时，让可执行python文件可以获取外部参数，形如：
```python
$ command.py [-h|--help]
$ command.py [位置参数] [-可选参数前缀 [可选参数]]
```

- 命令行参数分为必选参数和可选参数。
   - 必选参数：又名位置参数，即在参数值不需要跟在参数名后面，而是通过在命令行里的相对位置来决定其属于哪个参数，且该参数值不可缺少。
   - 可选参数：顾名思义，在命令行里可有可无，这取决于实际情况。参数值需要跟在以-或者–开头的参数名之后，由空格分隔开来。
```python
import argparse
from xmlrpc.client import boolean


def try_print(args):
    for name, value in vars(args).items():
        print(f"{name}: {value}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="测试命令行参数解析器")

    # 变量名前不加-或者--，表示该命令行参数为必须参数
    parser.add_argument("path")
    # 加上-或者--，表示该命令行参数为可选参数
    parser.add_argument("-p", "--port")
    # help：添加命令行参数备注，指定该命令行参数的说明信息。在执行-h或者--help时起作用
    parser.add_argument("-P", help="添加参数备注")
    # default：添加默认值。如果没有指定该命令行参数，则将默认值保存到变量里。
    parser.add_argument("--name", default="Kenny")
    # type：添加命令行参数值的类型校验，校验规则遵守类型转换，即1可通过int、str和bool等校验规则，"1"可通过str、boolean等校验规则。
    parser.add_argument("--age", type=bool)
    # choices：添加命令行参数值的备选值校验，即该命令行参数的参数值只能在choices里选择。区分大小写。
    # 不与default冲突，即default值可不在choices里，但一旦指定该命令行参数后，default设定失效，备选值按照choince的规则校验。
    parser.add_argument("--country", choices=["cn", "us"])
    # action：修改识别到命令行参数后的处理方式：
    #   store：直接保存命令行参数后的参数值到变量里。
    #   store_true：根据命令行参数值内容，将True或者False保存到变量里。
    #   store_const：与const参数共同使用，如果指定了该命令行参数，则将const的值保存到变量里。
    #   append：若命令行里多次出现该命令行参数且均指定了参数值，则将这些命令行参数值以列表的形式保存到变量里。
    parser.add_argument("--email", action="append")
    # const: 与action="store_const"参数一起使用。表示如果携带了该命令行参数，则将变量设定为const的值。
    parser.add_argument("--localhost", const="True", action="store_const")
    # nargs：允许命令行中该命令行参数后面跟多个命令行参数值，并以列表的形式将这些命令行参数值保存到变量里。
    #   N: 允许命令行参数值的绝对数量，不可多也不可少。
    #   *：允许任意个命令行参数值。
    #   +：允许至少一个命令行参数。
    #   ?：允许0个或1个命令行参数。
    parser.add_argument("--likes", nargs='*')
    # dest：默认解析器解析的命令行参数值保存在--或者-之后的变量里，使用dest参数后，可以将命令行参数值保存在指定的变量里。
    destvar = ""
    parser.add_argument("--append", dest=destvar)
	
    parser.print_help()
    # 通过parse_args方法解析，获得argparse.Namespace对象
    args = parser.parse_args()
    print(args, end="\n\n")

    # 如果要使用解析后的参数，可以通过类成员的方式调用该参数：
    print(args.port, args.name)

    # 循环遍历输出所有参数
    try_print(args)

    # 输出 dest= 对应变量值
    print(destvar)
```

# 0x10 pyinstaller

```
pyinstaller --onefile pythonScriptName.py
```

