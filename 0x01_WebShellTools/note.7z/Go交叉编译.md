Mac 下编译 Linux 和 Windows 64位可执行程序

    CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build main.go
    CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build main.go

Linux 下编译 Mac 和 Windows 64位可执行程序

    CGO_ENABLED=0 GOOS=darwin GOARCH=amd64 go build main.go
    CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build main.go

Windows 下编译 Mac 和 Linux 64位可执行程序

    SET CGO_ENABLED=0
    SET GOOS=darwin
    SET GOARCH=amd64
    go build main.go
    SET CGO_ENABLED=0
    SET GOOS=linux
    SET GOARCH=amd64
    go build main.go

GOOS：目标平台的操作系统（darwin、freebsd、linux、windows）
GOARCH：目标平台的体系架构（386、amd64、arm）
交叉编译不支持 CGO 所以要禁用它

上面的命令编译 64 位可执行程序，你当然应该也会使用 386 编译 32 位可执行程序
很多博客都提到要先增加对其它平台的支持，但是我跳过那一步，上面所列的命令也都能成功，且得到我想要的结果，可见那一步应该是非必须的，或是我所使用的 Go 版本已默认支持所有平台。

```
go build -trimpath -ldflags="-w -s" -o release/main.exe .\main.go 
```

```
go mod init
```



```
GOOS=linux GOARCH=mips64
```

- https://stackoverflow.com/questions/43208366/golang-cross-compiling-for-mips
  - https://golang.org/doc/install/source

```
 The Go compilers support the following instruction sets:

amd64, 386
    The x86 instruction set, 64- and 32-bit. 
arm64, arm
    The ARM instruction set, 64-bit (AArch64) and 32-bit. 
loong64
    The 64-bit LoongArch instruction set. 
mips64, mips64le, mips, mipsle
    The MIPS instruction set, big- and little-endian, 64- and 32-bit. 
ppc64, ppc64le
    The 64-bit PowerPC instruction set, big- and little-endian. 
riscv64
    The 64-bit RISC-V instruction set. 
s390x
    The IBM z/Architecture. 
wasm
    WebAssembly. 
```

