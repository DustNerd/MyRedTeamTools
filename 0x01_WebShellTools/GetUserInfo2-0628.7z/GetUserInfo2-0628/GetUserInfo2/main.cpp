#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include "cmdline.h"
#include <windows.h>
#include <assert.h>
#include <Winnetwk.h>
#include <lm.h>
#include <sddl.h>
#include <dsgetdc.h>
#include <DSRole.h>
#include <chrono>

#pragma comment(lib, "netapi32.lib")
#pragma comment(lib, "mpr.lib")

using namespace std;

inline wstring String2WString(const std::string& str);
void GetNetUserEnum(LPCWSTR ServerName);
void GetNetLocalGroupEnum(LPCWSTR ServerName);
void GetNetLocalGroupGetMembers(LPCWSTR ServerName, LPCWSTR LGroupName);
void GetNetGroupEnum(LPCWSTR ServerName);
void GetNetGroupGetUsers(LPCWSTR ServerName, LPCWSTR GroupName);
void GetNetUserGetInfo(LPCWSTR ServerName, LPCWSTR UserName);
void GetNetUserGetLocalGroups(LPCWSTR ServerName, LPCWSTR UserName);
void GetNetUserGetGroups(LPCWSTR ServerName, LPCWSTR UserName);
void GetWNetUseConnection(LPWSTR ServerName, LPCWSTR UserName, LPCWSTR Password);
void GetWNetCancelConnection2(LPCWSTR ServerName);
void GetNetUserGetGroups(LPCWSTR ServerName, LPCWSTR UserName);
LPWSTR GetDsGetDcName(LPCWSTR DomainName);
void GetUsage();
char* GetTime(time_t unix_timestamp);

int main(int argc, char* argv[])
{
    // create a parser
    cmdline::parser a;

    // add specified type of variable.
    // 1st argument is long name
    // 2nd argument is short name (no short name if '\0' specified)
    // 3rd argument is description
    // 4th argument is mandatory (optional. default is false)
    // 5th argument is default value  (optional. it used when mandatory is false)
    a.add<string>("user", 'u', "Specify a privileged username ", false, "");
    a.add<string>("pass", 'p', "Specify a privileged password", false, "");
    a.add<string>("server", 's', "Specify a machine IP that needs to be connected", false, "127.0.0.1");
    a.add<string>("domain", 'd', "Specify a windows domain name, only use in Domain Env", false, "");
    a.add<string>("nu", '\0', "Specify a username that needs to be accessed for detailed user information ", false, "");
    a.add("eu", '\0', "Enumerate all the local user lists of the specified machine");
    a.add("elg", '\0', "Enumerate all Local Group List");
    a.add("egg", '\0', "Enumerate all Domain Group List, Specify the server parameter (-s) for DC IP");
    a.add<string>("lgm", '\0', "Enumerate all the members of the specified local user group", false, "");
    a.add<string>("ggm", '\0', "Enumerate all the members of the specified domain user group", false, "");
    a.add("usage", '\0', "All Command Usage");
    
    a.parse_check(argc, argv);

    LPCWSTR ServerName = NULL;
    LPCWSTR LGroupName = NULL;
    LPCWSTR GroupName = NULL;
    LPCWSTR username = NULL;
    LPCWSTR password = NULL;
    LPCWSTR gusername = NULL;
    LPCWSTR DomainName = NULL;

    if (a.exist("usage"))
    {
        GetUsage();
        return 0;
    }

    wstring strhost = L"\\\\" + String2WString(a.get<string>("server"));
    ServerName = strhost.c_str();



    if (a.exist("domain"))
    {
        wstring strdn = String2WString(a.get<string>("domain"));
        DomainName = strdn.c_str();
        ServerName = GetDsGetDcName(DomainName);
    }

    if (a.exist("server") && a.exist("user") && a.exist("pass"))
    {
        wstring struser = String2WString(a.get<string>("user"));
        username = struser.c_str();
        wstring strpass = String2WString(a.get<string>("pass"));
        password = strpass.c_str();
        GetWNetUseConnection((LPWSTR)ServerName, username, password);
    }

    if (a.exist("eu"))
    {
        GetNetUserEnum(ServerName);
    }
    if (a.exist("elg"))
    {
        GetNetLocalGroupEnum(ServerName);
    }
    if (a.exist("lgm"))
    {
        wstring strlgn = String2WString(a.get<string>("lgm"));
        LGroupName = strlgn.c_str();
        GetNetLocalGroupGetMembers(ServerName, LGroupName);
    }
    if (a.exist("egg") && (a.exist("server") || a.exist("domain")))
    {  
        GetNetGroupEnum(ServerName);
    }
    if (a.exist("ggm") && (a.exist("server") || a.exist("domain")))
    {
        wstring strgn = String2WString(a.get<string>("ggm"));
        GroupName = strgn.c_str();
        GetNetGroupGetUsers(ServerName, GroupName);
    }
    if ((a.exist("egg") || a.exist("ggm")) && !(a.exist("server") || a.exist("domain")))
    {
        wprintf(L"Please manually specify a DC IP or DomainName for the server parameter !!!\n");
    }
    if (a.exist("nu"))
    {
        wstring strnu = String2WString(a.get<string>("nu"));
        gusername = strnu.c_str();
        GetNetUserGetInfo(ServerName, gusername);
        GetNetUserGetLocalGroups(ServerName, gusername);
        GetNetUserGetGroups(ServerName, gusername);
    }


    if (a.exist("user") && a.exist("pass"))
    {
        GetWNetCancelConnection2((LPWSTR)ServerName);
    }
}

void GetUsage()
{  
    wprintf(L"1. If you're currently in the Windows domain , You can try the following command.\n\n");
    wprintf(L"   GetUserInfo2.exe [--nu] [--eu] [--elg] [--egg] [--lgm] [--ggm] -d test.com [-u] [-p]\n\n");
    wprintf(L"   The -d parameter must specify an effective Windows domain name.\n");
    wprintf(L"\n2. If you're currently in the Windows WorkGroup , You can try the following command.\n\n");
    wprintf(L"   GetUserInfo2.exe [--nu] [--eu] [--elg] [--egg] [--lgm] [--ggm] -s 192.168.11.11 [-u] [-p]\n\n");       
    wprintf(L"   The -s parameter must specify an effective target IP, which can be DC IP.\n");       
    wprintf(L"\n3. If you don't specify -s or -d, the default target is a local machine.\n");       
    wprintf(L"\n4. You can get more detailed parameters to help information through -h or --help.\n");       
}

void GetNetUserEnum(LPCWSTR ServerName)
{
    LPCWSTR pszServerName = ServerName;
    LPUSER_INFO_0 pBuf = NULL;
    LPUSER_INFO_0 pTmpBuf;
    DWORD dwLevel = 0;
    DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
    DWORD dwEntriesRead = 0;
    DWORD dwTotalEntries = 0;
    DWORD dwResumeHandle = 0;
    DWORD i;
    DWORD dwTotalCount = 0;
    NET_API_STATUS nStatus;

    // Call the NetUserEnum function, specifying level 0; enumerate global user account types only.
    wprintf(L"List all Users of the Computer [%s]\n", pszServerName);
    wprintf(L"---------------------------------------------------------------\n");

    do
    {
        nStatus = NetUserEnum(
            pszServerName,
            dwLevel,
            FILTER_NORMAL_ACCOUNT, // global users
            (LPBYTE*)&pBuf,
            dwPrefMaxLen,
            &dwEntriesRead,
            &dwTotalEntries,
            &dwResumeHandle);
        // If the call succeeds,
        if ((nStatus == NERR_Success) || (nStatus == ERROR_MORE_DATA))
        {
            if ((pTmpBuf = pBuf) != NULL)
            {
                // Loop through the entries.
                for (i = 0; (i < dwEntriesRead); i++)
                {
                    assert(pTmpBuf != NULL);
                    if (pTmpBuf == NULL)
                    {
                        fprintf(stderr, "An access violation has occurred\n");
                        break;
                    }
                    wprintf(L" - %s\n", pTmpBuf->usri0_name);
                    pTmpBuf++;
                    dwTotalCount++;
                }
            }
        }
        else
        {
            fprintf(stderr, "A system error has occurred: %d\n", nStatus);
            return;
        }
        // Free the allocated buffer.
        if (pBuf != NULL)
        {
            NetApiBufferFree(pBuf);
            pBuf = NULL;
        }
    }
    // Continue to call NetUserEnum while ; there are more entries.  
    while (nStatus == ERROR_MORE_DATA);
    if (pBuf != NULL)
        NetApiBufferFree(pBuf);
    // Print the final count of users enumerated.
    wprintf(L"---------------------------------------------------------------\n");
    fprintf(stderr, "Total of %d entries enumerated\n", dwTotalCount);
}

void GetNetLocalGroupEnum(LPCWSTR ServerName)
{
    LPCWSTR pszServerName = ServerName;
    LPLOCALGROUP_INFO_0 pBuf = NULL;
    LPLOCALGROUP_INFO_0 pTmpBuf;
    DWORD dwLevel = 0;
    DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
    DWORD dwEntriesRead = 0;
    DWORD dwTotalEntries = 0;
    DWORD dwResumeHandle = 0;
    DWORD dwTotalCount = 0;
    NET_API_STATUS nStatus;

    wprintf(L"List all Local Groups of the Computer [%s]\n", pszServerName);
    wprintf(L"---------------------------------------------------------------\n");

    do
    {
        nStatus = NetLocalGroupEnum(
            pszServerName,
            dwLevel,
            (LPBYTE*)&pBuf,
            dwPrefMaxLen,
            &dwEntriesRead,
            &dwTotalEntries,
            &dwResumeHandle);

        if ((nStatus == NERR_Success) || (nStatus == ERROR_MORE_DATA)) {
            if ((pTmpBuf = pBuf) != NULL)
            {
                // Loop through the entries.
                for (DWORD i = 0; (i < dwEntriesRead); i++)
                {
                    assert(pTmpBuf != NULL);
                    if (pTmpBuf == NULL)
                    {
                        fprintf(stderr, "An access violation has occurred\n");
                        break;
                    }
                    wprintf(L" - %s\n", pTmpBuf->lgrpi0_name);
                    pTmpBuf++;
                    dwTotalCount++;
                }
            }
        }
        else
        {
            fprintf(stderr, "A system error has occurred: %d\n", nStatus);
            return;
        }

        // Free the allocated buffer.
        if (pBuf != NULL)
        {
            NetApiBufferFree(pBuf);
            pBuf = NULL;
        }
    }
    // Continue to call NetUserEnum while ; there are more entries. 
    while (nStatus == ERROR_MORE_DATA);
    if (pBuf != NULL)
        NetApiBufferFree(pBuf);
    // Print the final count of users enumerated.
    wprintf(L"---------------------------------------------------------------\n");
    fprintf(stderr, "Total of %d entries enumerated\n", dwTotalCount);
}

void GetNetLocalGroupGetMembers(LPCWSTR ServerName, LPCWSTR LGroupName)
{
    LPCWSTR pszServerName = ServerName;
    LPLOCALGROUP_MEMBERS_INFO_1 pBuf = NULL;
    LPLOCALGROUP_MEMBERS_INFO_1 pTmpBuf;
    LPCWSTR localgroupname = LGroupName;
    DWORD dwLevel = 1;
    DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
    DWORD dwEntriesRead = 0;
    DWORD dwTotalEntries = 0;
    DWORD dwResumeHandle = 0;
    DWORD dwTotalCount = 0;
    NET_API_STATUS nStatus;

    wprintf(L"List all Local Group Members of the Computer [%s]\n", pszServerName);
    wprintf(L"---------------------------------------------------------------\n");

    do
    {
        nStatus = NetLocalGroupGetMembers(
            pszServerName,
            localgroupname,
            dwLevel,
            (LPBYTE*)&pBuf,
            dwPrefMaxLen,
            &dwEntriesRead,
            &dwTotalEntries,
            &dwResumeHandle);

        if ((nStatus == NERR_Success) || (nStatus == ERROR_MORE_DATA)) {
            if ((pTmpBuf = pBuf) != NULL)
            {
                // Loop through the entries.
                for (DWORD i = 0; (i < dwEntriesRead); i++)
                {
                    assert(pTmpBuf != NULL);
                    if (pTmpBuf == NULL)
                    {
                        fprintf(stderr, "An access violation has occurred\n");
                        break;
                    }
                    wprintf(L" - %s\n", pTmpBuf->lgrmi1_name);
                    pTmpBuf++;
                    dwTotalCount++;
                }
            }
        }
        else
        {
            fprintf(stderr, "A system error has occurred: %d\n", nStatus);
            return;
        }
        // Free the allocated buffer.
        if (pBuf != NULL)
        {
            NetApiBufferFree(pBuf);
            pBuf = NULL;
        }
    }
    // Continue to call NetUserEnum while ; there are more entries. 
    while (nStatus == ERROR_MORE_DATA);
    if (pBuf != NULL)
        NetApiBufferFree(pBuf);
    // Print the final count of users enumerated.
    wprintf(L"---------------------------------------------------------------\n");
    fprintf(stderr, "Total of %d entries enumerated\n", dwTotalCount);
}

void GetNetGroupEnum(LPCWSTR ServerName)
{
    LPCWSTR pszServerName = ServerName;
    LPGROUP_INFO_0 pBuf = NULL;
    LPGROUP_INFO_0 pTmpBuf;
    DWORD dwLevel = 0;
    DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
    DWORD dwEntriesRead = 0;
    DWORD dwTotalEntries = 0;
    DWORD dwResumeHandle = 0;
    DWORD dwTotalCount = 0;
    NET_API_STATUS nStatus;
    do
    {
        nStatus = NetGroupEnum(
            pszServerName,
            dwLevel,
            (LPBYTE*)&pBuf,
            dwPrefMaxLen,
            &dwEntriesRead,
            &dwTotalEntries,
            &dwResumeHandle);

        if ((nStatus == NERR_Success) || (nStatus == ERROR_MORE_DATA)) {
            wprintf(L"The request will be processed at a domain controller for %s\n", pszServerName);
            wprintf(L"---------------------------------------------------------------\n");
            if ((pTmpBuf = pBuf) != NULL)
            {
                // Loop through the entries.
                for (DWORD i = 0; (i < dwEntriesRead); i++)
                {
                    assert(pTmpBuf != NULL);
                    if (pTmpBuf == NULL)
                    {
                        fprintf(stderr, "An access violation has occurred\n");
                        break;
                    }
                    wprintf(L" - %s\n", pTmpBuf->grpi0_name);
                    pTmpBuf++;
                    dwTotalCount++;
                }
            }
        }
        else
        {
            fprintf(stderr, "A system error has occurred: %d\n", nStatus);
            return;
        }
        if (pBuf != NULL)
        {
            NetApiBufferFree(pBuf);
            pBuf = NULL;
        }
    }
    // Continue to call NetUserEnum while ; there are more entries. 
    while (nStatus == ERROR_MORE_DATA);
    if (pBuf != NULL)
        NetApiBufferFree(pBuf);
    // Print the final count of users enumerated.
    wprintf(L"---------------------------------------------------------------\n");
    fprintf(stderr, "Total of %d entries enumerated\n", dwTotalCount);
}

void GetNetGroupGetUsers(LPCWSTR ServerName, LPCWSTR GroupName)
{
    LPCWSTR pszServerName = ServerName;
    LPCWSTR groupname = GroupName;
    LPGROUP_USERS_INFO_1 pBuf = NULL;
    LPGROUP_USERS_INFO_1 pTmpBuf;
    DWORD dwLevel = 1;
    DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
    DWORD dwEntriesRead = 0;
    DWORD dwTotalEntries = 0;
    DWORD dwResumeHandle = 0;
    DWORD dwTotalCount = 0;
    NET_API_STATUS nStatus;

    do
    {
        nStatus = NetGroupGetUsers(pszServerName,
            groupname,
            dwLevel,
            (LPBYTE*)&pBuf,
            dwPrefMaxLen,
            &dwEntriesRead,
            &dwTotalEntries,
            &dwResumeHandle);

        if ((nStatus == NERR_Success) || (nStatus == ERROR_MORE_DATA)) {
            wprintf(L"The request will be processed at a domain controller for %s.\n", pszServerName);
            wprintf(L"---------------------------------------------------------------\n");
            if ((pTmpBuf = pBuf) != NULL)
            {
                // Loop through the entries.
                for (DWORD i = 0; (i < dwEntriesRead); i++)
                {
                    assert(pTmpBuf != NULL);
                    if (pTmpBuf == NULL)
                    {
                        fprintf(stderr, "An access violation has occurred\n");
                        break;
                    }
                    wprintf(L" - %s\n", pTmpBuf->grui1_name);
                    pTmpBuf++;
                    dwTotalCount++;
                }
            }
        }
        else
        {
            fprintf(stderr, "A system error has occurred: %d\n", nStatus);
            return;
        }

        if (pBuf != NULL)
        {
            NetApiBufferFree(pBuf);
            pBuf = NULL;
        }
    }
    // Continue to call NetUserEnum while ; there are more entries. 
    while (nStatus == ERROR_MORE_DATA);
    if (pBuf != NULL)
        NetApiBufferFree(pBuf);
    // Print the final count of users enumerated.
    wprintf(L"---------------------------------------------------------------\n");
    fprintf(stderr, "Total of %d entries enumerated\n", dwTotalCount);
}

void GetNetUserGetInfo(LPCWSTR ServerName, LPCWSTR UserName)
{
    LPUSER_INFO_4 pBuf4 = NULL;
    LPUSER_INFO_4 pBuf = NULL;
    NET_API_STATUS nStatus;
    DWORD dwLevel = 4;
    LPTSTR sStringSid = NULL;

 
    int j = 0;

    
    //
    // Call the NetUserGetInfo function.
    //
    nStatus = NetUserGetInfo(ServerName, UserName, dwLevel, (LPBYTE*)&pBuf);
    //
    // If the call succeeds, print the user information.
    //
    if (nStatus == NERR_Success)
    {
        if (pBuf != NULL)
        {

            pBuf4 = (LPUSER_INFO_4)pBuf;
            wprintf(L"User name:\t\t\t%s\n", pBuf4->usri4_name);
            wprintf(L"Full name:\t\t\t%s\n", pBuf4->usri4_full_name);
            wprintf(L"Comment:  \t\t\t%s\n", pBuf4->usri4_comment);
            wprintf(L"User comment:\t\t%s\n", pBuf4->usri4_usr_comment);
            if (ConvertSidToStringSid(pBuf4->usri4_user_sid, &sStringSid))
            {
                wprintf(L"User SID:\t\t\t%s\n", sStringSid);
                LocalFree(sStringSid);
            }
            else
                wprintf(L"ConvertSidToSTringSid failed with error %d\n",
                    GetLastError());
            if(pBuf4->usri4_country_code == 0)
                wprintf(L"Country/region code:\t\t000 (System Default)\n");
            else
                wprintf(L"Country/region code:\t\t%d\n", pBuf4->usri4_country_code);
            wprintf(L"Code page:\t\t\t%d\n", pBuf4->usri4_code_page);
            
            if(pBuf4->usri4_priv == USER_PRIV_GUEST)
                wprintf(L"Privilege level:\t\tGuest\n");
            if(pBuf4->usri4_priv == USER_PRIV_USER)
                wprintf(L"Privilege level:\t\tUser\n");
            if(pBuf4->usri4_priv == USER_PRIV_ADMIN)
                wprintf(L"Privilege level:\t\tAdministrator\n");
            wprintf(L"Flags (in hex):\t\t\t%x\n", pBuf4->usri4_flags);
            wprintf(L"Auth flags (in hex):\t\t%x\n", pBuf4->usri4_auth_flags);
            wprintf(L"Parameters:\t\t\t%s\n\n", pBuf4->usri4_parms);

            time_t acct_expires_time = pBuf4->usri4_acct_expires;
            if (pBuf4->usri4_acct_expires == TIMEQ_FOREVER)
                wprintf(L"Account expires :\t\tNever\n");
            else
                wprintf(L"Account expires :\t\t\t%S\n", GetTime(acct_expires_time));
            if ((pBuf4->usri4_flags & UF_ACCOUNTDISABLE) != 0)
                wprintf(L"Account active:\t\t\tNo\n");
            else
                wprintf(L"Account active:\t\t\tYes\n");

            wprintf(L"\nWorkstations: %s\t\t\t\n", pBuf4->usri4_workstations);
            wprintf(L"Logon script: %s\t\t\t\n", pBuf4->usri4_script_path);
            wprintf(L"User profile: %s\t\t\n", pBuf4->usri4_profile);
            wprintf(L"Home directory: %s\t\t\n", pBuf4->usri4_home_dir);
            //wprintf(L"Password: %s\n", pBuf4->usri4_password);
            time_t now = time(0);
            time_t password_changeable_time = now - pBuf4->usri4_password_age;
            wprintf(L"\nPassword last set:\t\t%S (%d)\n", GetTime(password_changeable_time), pBuf4->usri4_password_age);
            if (pBuf4->usri4_password_expired == 0)
                wprintf(L"Password expires:\t\tNever\n");
            else
                wprintf(L"Password expires:\t\tYes\n");
            wprintf(L"Password changeable:\t\t%S (%d)\n", GetTime(password_changeable_time), pBuf4->usri4_password_age);
            if ((pBuf4->usri4_flags & UF_PASSWD_NOTREQD) != 0)
                wprintf(L"Password required:\t\tNo\n");
            else
                wprintf(L"Password required:\t\tYes\n");
            if ((pBuf4->usri4_flags & UF_PASSWD_CANT_CHANGE) != 0)
                wprintf(L"User may change password:\tNo\n");
            else
                wprintf(L"User may change password:\tYes\n");
            //wprintf(L"Password age (seconds): %d\n", pBuf4->usri4_password_age);

            time_t last_logon_time = pBuf4->usri4_last_logon;
            wprintf(L"\nLast logon :\t\t\t%S (%d)\n", GetTime(last_logon_time), pBuf4->usri4_last_logon);
            //wprintf(L"Last logoff : %d\n",pBuf4->usri4_last_logoff);
            
           
            wprintf(L"Logon hours:                   ");
            int flagAll = 0;
            for (j = 0; j < 21; j++)
            {   
                if ((BYTE)pBuf4->usri4_logon_hours[j] == 0xFF)
                    flagAll++;
                printf(" %x", (BYTE)pBuf4->usri4_logon_hours[j]);
            }
            if(flagAll == 21)
                wprintf(L"\nLogon hours allowed :\t\tAll\n");
            wprintf(L"Units per week:\t\t\t%d\n", pBuf4->usri4_units_per_week);

            wprintf(L"Bad password count:\t\t%d\n",
                pBuf4->usri4_bad_pw_count);
            wprintf(L"Number of logons:\t\t%d\n",
                pBuf4->usri4_num_logons);
            wprintf(L"Logon server:\t\t\t%s\n", pBuf4->usri4_logon_server);
            if(pBuf4->usri4_max_storage == USER_MAXSTORAGE_UNLIMITED)
                wprintf(L"Max storage:\t\t\tUnrestricted\n");
            else
                wprintf(L"Max storage:\t\t\t%d\n", pBuf4->usri4_max_storage);
            
            wprintf(L"Primary group ID:\t\t%d\n",
                pBuf4->usri4_primary_group_id);
            
            wprintf(L"Home directory drive letter: %s\n",
                pBuf4->usri4_home_dir_drive);
        }
    }
    // Otherwise, print the system error.
    //
    else
        fprintf(stderr, "NetUserGetinfo failed with error: %d\n", nStatus);
    //
    // Free the allocated memory.
    //
    if (pBuf != NULL)
        NetApiBufferFree(pBuf);
}

void GetNetUserGetLocalGroups(LPCWSTR ServerName, LPCWSTR UserName)
{
    LPLOCALGROUP_USERS_INFO_0 pBuf = NULL;
    DWORD dwLevel = 0;
    DWORD dwFlags = LG_INCLUDE_INDIRECT;
    DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
    DWORD dwEntriesRead = 0;
    DWORD dwTotalEntries = 0;
    NET_API_STATUS nStatus;

    //
    // Call the NetUserGetLocalGroups function 
    //  specifying information level 0.
    //
    //  The LG_INCLUDE_INDIRECT flag specifies that the 
    //   function should also return the names of the local 
    //   groups in which the user is indirectly a member.
    //
    nStatus = NetUserGetLocalGroups(ServerName,
        UserName,
        dwLevel,
        dwFlags,
        (LPBYTE*)&pBuf,
        dwPrefMaxLen,
        &dwEntriesRead,
        &dwTotalEntries);
    //
    // If the call succeeds,
    //
    if (nStatus == NERR_Success)
    {
        LPLOCALGROUP_USERS_INFO_0 pTmpBuf;
        DWORD i;
        DWORD dwTotalCount = 0;

        if ((pTmpBuf = pBuf) != NULL)
        {
            fprintf(stderr, "\nLocal Group Memberships:\n");
            //
            // Loop through the entries and 
            //  print the names of the local groups 
            //  to which the user belongs. 
            //
            for (i = 0; i < dwEntriesRead; i++)
            {
                assert(pTmpBuf != NULL);

                if (pTmpBuf == NULL)
                {
                    fprintf(stderr, "An access violation has occurred\n");
                    break;
                }

                wprintf(L" *%s\n", pTmpBuf->lgrui0_name);

                pTmpBuf++;
                dwTotalCount++;
            }
        }
        //
        // If all available entries were
        //  not enumerated, print the number actually 
        //  enumerated and the total number available.
        //
        if (dwEntriesRead < dwTotalEntries)
            fprintf(stderr, "\nTotal entries: %d", dwTotalEntries);
        //
        // Otherwise, just print the total.
        //
        //printf("\nEntries enumerated: %d\n", dwTotalCount);
    }
    else
        fprintf(stderr, "A system error has occurred: %d\n", nStatus);
    //
    // Free the allocated memory.
    //
    if (pBuf != NULL)
        NetApiBufferFree(pBuf);
}

void GetNetUserGetGroups(LPCWSTR ServerName, LPCWSTR UserName)
{
    LPGROUP_USERS_INFO_1 pBuf = NULL;

    DWORD dwLevel = 1;
    DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
    DWORD dwEntriesRead = 0;
    DWORD dwTotalEntries = 0;
    NET_API_STATUS nStatus;

    //  Call the NetUserGetLocalGroups function 
    //  specifying information level 0.
    //  The LG_INCLUDE_INDIRECT flag specifies that the 
    //   function should also return the names of the local 
    //   groups in which the user is indirectly a member.
    nStatus = NetUserGetGroups(ServerName,
        UserName,
        dwLevel,
        (LPBYTE*)&pBuf,
        dwPrefMaxLen,
        &dwEntriesRead,
        &dwTotalEntries);
    // If the call succeeds,
    if (nStatus == NERR_Success)
    {
        LPGROUP_USERS_INFO_1 pTmpBuf;
        DWORD i;
        DWORD dwTotalCount = 0;

        if ((pTmpBuf = pBuf) != NULL)
        {
            fprintf(stderr, "\nGlobal Group memberships:\n");
            // Loop through the entries and 
            //  print the names of the local groups 
            //  to which the user belongs. 

            //wprintf(L" - %d\n", dwEntriesRead);
            for (i = 0; i < dwEntriesRead; i++)
            {
                assert(pTmpBuf != NULL);

                if (pTmpBuf == NULL)
                {
                    fprintf(stderr, "An access violation has occurred\n");
                    break;
                }

                wprintf(L" *%s\n", pTmpBuf->grui1_name);
                pTmpBuf++;
                dwTotalCount++;
            }
        }
        // If all available entries were
        //  not enumerated, print the number actually 
        //  enumerated and the total number available.
        if (dwEntriesRead < dwTotalEntries)
            fprintf(stderr, "\nTotal entries: %d", dwTotalEntries);
        // Otherwise, just print the total.
        //printf("\nEntries enumerated: %d\n", dwTotalCount);
    }
    else
        fprintf(stderr, "A system error has occurred: %d\n", nStatus);
    // Free the allocated memory.
    if (pBuf != NULL)
        NetApiBufferFree(pBuf);
}

void GetWNetUseConnection(LPWSTR ServerName, LPCWSTR UserName, LPCWSTR Password)
{
    DWORD dwRetVal;
    NETRESOURCE nr;

    // Zero out the NETRESOURCE struct
    memset(&nr, 0, sizeof(NETRESOURCE));

    // Assign our values to the NETRESOURCE structure.

    nr.dwType = RESOURCETYPE_ANY;
    nr.lpRemoteName = ServerName;
    nr.lpProvider = NULL;
    LPCWSTR username = UserName;
    LPCWSTR password = Password;
    LPWSTR lpAccessName = NULL;
    DWORD dwFlags = CONNECT_COMMANDLINE;
    LPDWORD lpbufferSize = NULL;
    LPDWORD lpResult = NULL;

    // Assign a value to the connection options
    dwRetVal = WNetUseConnectionW(NULL, &nr, password, username, dwFlags, lpAccessName, lpbufferSize, lpResult);

    // If the call succeeds, inform the user; otherwise print the error.
    if (dwRetVal == NO_ERROR)
        wprintf(L"[+] %s connection add successful\n", nr.lpRemoteName);
    else
    {
        wprintf(L"[-] Connection failed with error: %u\n", dwRetVal);
        exit(1);
    }
    wprintf(L"---------------------------------------------------------------\n");
}

void GetWNetCancelConnection2(LPCWSTR ServerName)
{
    DWORD dwRetVal;
    LPCWSTR lpName = ServerName;
    DWORD dwFlags = CONNECT_UPDATE_PROFILE;
    BOOL fForce = TRUE;

    dwRetVal = WNetCancelConnection2W(lpName, dwFlags, fForce);

    // If the call succeeds, inform the user; otherwise,
    //  print the error.
    wprintf(L"---------------------------------------------------------------\n");
    if (dwRetVal == NO_ERROR)
        wprintf(L"[+] %s connection delete successful \n", lpName);
    else
        wprintf(L"[-] WNetCancelConnection2W failed with error: %u\n", dwRetVal);
}

LPWSTR GetDsGetDcName(LPCWSTR DomainName)
{
    LPCWSTR ComputerName = NULL;
    GUID* DomainGuid = NULL;
    LPCWSTR SiteName = NULL;
    ULONG  Flags = DS_IS_DNS_NAME;
    PDOMAIN_CONTROLLER_INFOW DomainControllerInfo;
    DWORD dw;

    dw = DsGetDcNameW(ComputerName,
        DomainName,
        DomainGuid,
        SiteName,
        Flags,
        (PDOMAIN_CONTROLLER_INFOW*)&DomainControllerInfo
    );

    if (dw == ERROR_SUCCESS)
    {
        wprintf(L"[+] DCName : %s \n", DomainControllerInfo->DomainControllerName);
        wprintf(L"[+] DCAddress : %s \n", DomainControllerInfo->DomainControllerAddress);
        wprintf(L"[+] DCDnsForestName : %s \n", DomainControllerInfo->DnsForestName);
        wprintf(L"---------------------------------------------------------------\n");
        return DomainControllerInfo->DomainControllerAddress;
    }
    else
    {
        fprintf(stderr, "A system error has occurred: %d\n", dw);
    }
    if (DomainControllerInfo != NULL)
        NetApiBufferFree(DomainControllerInfo);
}

inline wstring String2WString(const std::string& str)
{
    int size_needed = MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), NULL, 0);
    std::wstring wstrTo(size_needed, 0);
    MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), &wstrTo[0], size_needed);
    return wstrTo;
}

char* GetTime(time_t unix_timestamp)
{
    char time_buf[80];
    struct tm ts;
    ts = *localtime(&unix_timestamp);
    strftime(time_buf, sizeof(time_buf), "%a %Y-%m-%d %H:%M:%S %p", &ts);

    return time_buf;
}